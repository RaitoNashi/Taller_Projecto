package alta;

import conexion.Conexiónsql;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author 54255702
 */

public class cliente {
    
    public static boolean Altacliente(String Direcion,String Nombre, String Telefono) throws SQLException{
        boolean resultado=true;
         Conexiónsql alta = new Conexiónsql();
         Connection conn = null;
        PreparedStatement psmt = null;
        Scanner a = new Scanner(System.in);
        
        conn = alta.getConnection();
          // Preparar la sentencia SQL
                        String sql = "INSERT INTO cliente (Dirección, Nombre, Teléfono) VALUES (?,?,?)";
                        psmt = conn.prepareStatement(sql);
                        // Establecer los valores en el PreparedStatement
                        psmt.setString(1, Direcion);
                        psmt.setString(2, Nombre);
                        psmt.setString(3, Telefono);
                        // Ejecutar la sentencia y obtener el número de filas afectadas
                        int filasAfectadas = psmt.executeUpdate();
                        if(filasAfectadas>0){
                            conn.commit();
                        System.out.println("Filas insertadas: " + filasAfectadas);
                        }else{
                            conn.rollback();
                        }
                        // Cerrar el PreparedStatement
                     psmt.close();
    
        return resultado;
        
    }
    public static boolean BorrarCliente(String Nombre,String Telefono){
        boolean resulta=true;
        
        
        
        
        
        
        return false;  
    }
    
    
    
    
    
    
}
