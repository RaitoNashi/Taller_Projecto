package Controlador.Cliente_Controller;


import alta.cliente;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;

/**
 * FXML Controller class
 *
 * @author 54255702
 */
public class Dar_de_alta_clienteController implements Initializable {
    //cliente cli=new cliente();
    boolean resss;
    @FXML
    private TextArea txtCedula;
    @FXML
    private TextArea txtNombre;
    @FXML
    private TextArea txtApellido;
    @FXML
    private TextArea txtDirecion;
    @FXML
    private TextArea txtTelefono;
    @FXML
    private Button btenviar;
    @FXML
    private Button btcancelar;

    public void crearCliente() throws SQLException {
        String Nombre = txtNombre.getText();
        String apellido = txtApellido.getText();
        String Direcion = txtDirecion.getText();
        String Cedula = txtCedula.getText();
        String Telefono = txtTelefono.getText();
       // boolean enviar=btenviar;
       // boolean btcancelar;
                
                
        Nombre+=apellido; 
        // Llamada al método que recibe los parámetros
        resss=cliente.Altacliente(Direcion,Nombre,Telefono);
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void enviar(ActionEvent event) {
    }
    
}
