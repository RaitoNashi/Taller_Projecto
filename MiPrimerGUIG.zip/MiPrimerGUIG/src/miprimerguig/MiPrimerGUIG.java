package miprimerguig;

import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class MiPrimerGUIG extends Application {

  @Override
    public void start(Stage primaryStage) {

        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(MiPrimerGUIG.class.getResource("vista/Dar_de_alta_cliente.fxml"));
            Pane ventana = (Pane) loader.load();

            // Show the scene containing the root layout.
            Scene scene = new Scene(ventana);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
    
}
    
  /*  @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/vista/Dar_de_alta_cliente.fxml"));
        primaryStage.setTitle("Mi Aplicación");
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
        
        
        
        Scanner n = new Scanner(System.in);
        Conexiónsql alta = new Conexiónsql(); // Asumimos que Conexiónsql establece la conexión
        cliente cli= new cliente();
        boolean resul;  
        System.out.println("Ingrese el nombre: ");
        String nom=n.nextLine();
        System.out.println("Ingrese el Teléfono: ");
        String tel=n.nextLine();
        System.out.println("Ingrese el Direccion: ");
        String dire=n.nextLine();
        resul=cliente.Altacliente(dire, nom, tel);
        if(resul==true){
            System.out.println("Agregado con exito");
                  
        }else{
            System.out.println("Nopi agregado co nexito");
        }
        Connection conn = null;
        PreparedStatement psmt = null;
        Scanner scanner = new Scanner(System.in);
        boolean opcion = true;

        try {
            // Obtener la conexión a la base de datos
            conn = alta.getConnection();

          
                        // Preparar la sentencia SQL
                        String sql = "INSERT INTO cliente (Nombre) VALUES (?)";
                        psmt = conn.prepareStatement(sql);

                        // Obtener los datos del usuario
                       
                        
                        System.out.print("Ingrese el nombre: ");
                        String nombre = scanner.next();
                        
                         //System.out.print("Ingrese la direci´n: ");
                       // String Direción = scanner.next();
                      //  System.out.print("Ingrese el apellido: ");
                        //String apellido = scanner.next();
 
                        // Establecer los valores en el PreparedStatement
                       // psmt.setInt(1,ID_Cliente);
                        psmt.setString(1, nombre);
                       // psmt.setString(2, apellido);

                        // Ejecutar la sentencia y obtener el número de filas afectadas
                        int filasAfectadas = psmt.executeUpdate();
                        if(filasAfectadas>0){
                            conn.commit();
                        System.out.println("Filas insertadas: " + filasAfectadas);
                        }else{
                            conn.rollback();
                        }

                        // Cerrar el PreparedStatement
                        psmt.close();
                  
        } catch (SQLException e) {
            System.err.println("Error al ejecutar la consulta: " + e.getMessage());
        } finally {
            // Cerrar la conexión (si es necesario, dependiendo de tu implementación de Conexiónsql)
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }*/