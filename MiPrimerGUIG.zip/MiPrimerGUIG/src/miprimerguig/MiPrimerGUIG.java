package miprimerguig;

import alta.cliente;
import controlador.Conexiónsql;
import java.sql.*;
import java.util.Scanner;

public class MiPrimerGUIG {
       
    public static void main(String[] args) throws SQLException {
         Scanner n = new Scanner(System.in);
        Conexiónsql alta = new Conexiónsql(); // Asumimos que Conexiónsql establece la conexión
        cliente cli= new cliente();
        boolean resul;  
        System.out.println("Ingrese el nombre: ");
        String nom=n.nextLine();
        System.out.println("Ingrese el Teléfono: ");
        String tel=n.nextLine();
        System.out.println("Ingrese el Direccion: ");
        String dire=n.nextLine();
        resul=cliente.Altacliente(dire, nom, tel);
        if(resul==true){
            System.out.println("Agregado con exito");
                  
        }else{
            System.out.println("Nopi agregado co nexito");
        }
      /*  
        Connection conn = null;
        PreparedStatement psmt = null;
        Scanner scanner = new Scanner(System.in);
        boolean opcion = true;

        try {
            // Obtener la conexión a la base de datos
            conn = alta.getConnection();

          
                        // Preparar la sentencia SQL
                        String sql = "INSERT INTO cliente (Nombre) VALUES (?)";
                        psmt = conn.prepareStatement(sql);

                        // Obtener los datos del usuario
                       
                        
                        System.out.print("Ingrese el nombre: ");
                        String nombre = scanner.next();
                        
                         //System.out.print("Ingrese la direci´n: ");
                       // String Direción = scanner.next();
                      //  System.out.print("Ingrese el apellido: ");
                        //String apellido = scanner.next();
 
                        // Establecer los valores en el PreparedStatement
                       // psmt.setInt(1,ID_Cliente);
                        psmt.setString(1, nombre);
                       // psmt.setString(2, apellido);

                        // Ejecutar la sentencia y obtener el número de filas afectadas
                        int filasAfectadas = psmt.executeUpdate();
                        if(filasAfectadas>0){
                            conn.commit();
                        System.out.println("Filas insertadas: " + filasAfectadas);
                        }else{
                            conn.rollback();
                        }

                        // Cerrar el PreparedStatement
                        psmt.close();
                  
        } catch (SQLException e) {
            System.err.println("Error al ejecutar la consulta: " + e.getMessage());
        } finally {
            // Cerrar la conexión (si es necesario, dependiendo de tu implementación de Conexiónsql)
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }*/
      
      
    }
}