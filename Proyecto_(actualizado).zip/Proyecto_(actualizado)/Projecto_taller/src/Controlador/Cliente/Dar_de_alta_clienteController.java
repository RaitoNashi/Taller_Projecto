/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador.Cliente;

import Controlador.SceneManager;
import Modelo.Cliente1;
import Modelo.Conexiónsql;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;
import javafx.scene.control.Button;

/**
 * FXML Controller class
 *
 * @author raito
 */
public class Dar_de_alta_clienteController implements Initializable {
    
    @FXML
    private TextArea ClienteNombre;
    
    @FXML
    private TextArea ClienteApellido;
    
    @FXML
    private TextArea ClienteCedula;
    
    @FXML
    private TextArea ClienteDireccion;
    
    @FXML
    private TextArea ClienteTelefono;
    
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    public void HandleVolverMenuCliente(ActionEvent event){
        SceneManager.getInstance().goBackMenuCliente();
    }
    
    @FXML
    public void HandleEnviar(ActionEvent event)throws SQLException{
            Modelo.Cliente1 ClienteEnvio = new Cliente1();
            boolean resultado=true;
            String nombre=ClienteNombre.getText();
            String direccion=ClienteDireccion.getText();
            String t=ClienteTelefono.getText();                       
            String apellido=ClienteApellido.getText();
            String cedula=ClienteCedula.getText();
            int telefono=Integer.parseInt(t);
            
            resultado=Modelo.Cliente1.Altacliente(nombre, direccion, telefono, apellido, cedula);
        }
    
    
}
