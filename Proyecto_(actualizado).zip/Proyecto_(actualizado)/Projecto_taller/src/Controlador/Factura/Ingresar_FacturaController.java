/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador.Factura;

import Controlador.SceneManager;
import Modelo.Cliente1;
import Modelo.Conexiónsql;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import java.util.ArrayList;

/**
 * FXML Controller class
 *
 * @author raito
 */
public class Ingresar_FacturaController implements Initializable {
     Conexiónsql alta = new Conexiónsql();
         Connection conn = null;
      
    @FXML
    private ComboBox<String> conxxx;  // ComboBox de JavaFX
    
    @FXML
    private TextField IDVenta;
    
    @FXML
    private TextField IDProducto;
    
    @FXML
    private TextField CantProducto;
    
    @FXML
    private TextField Cedula;
 
     @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO     
        llenarComboBoxConDatos();
    }  
    
     public void MostrarMenuPrincipal(){
        SceneManager.getInstance().goBack();
    }
    
    //Este PopUp está iniciliazado en el controlador SceneManager
    public void MostrarPopUp(){
        SceneManager.getInstance().MostrarPopUp();
        limpiarCampos();
    }
    
    private void limpiarCampos(){
        IDVenta.clear();
        IDProducto.clear();
        CantProducto.clear();
        Cedula.clear();
        
    }
    
     private void llenarComboBoxConDatos() {
           // Crear una instancia de la clase que obtiene los datos de la BD
           Modelo.Cliente1 cli1 = new Modelo.Cliente1();
        // Llamar al método que obtiene los datos
        ArrayList<String> listaDeProductos = cli1.cargarDatosEnComboBox();

        // Limpiar el ComboBox antes de agregar nuevos datos
        conxxx.getItems().clear();

        // Llenar el ComboBox con los datos obtenidos
        conxxx.getItems().addAll(listaDeProductos);
    }
 
}
    