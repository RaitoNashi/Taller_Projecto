package Modelo;

import Controlador.Factura.Ingresar_FacturaController;
import com.mysql.cj.xdevapi.Statement;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

/**
 *
 * @author 54255702
 */

public class Cliente1 {
    //Metodo 1
    public static boolean Altacliente(String nombre, String direccion, int telefono, String apellido, String cedula) throws SQLException{
        boolean resultado=true;
        
         Conexiónsql alta = new Conexiónsql();
         Connection conn = null;
        PreparedStatement psmt = null;
        Scanner a = new Scanner(System.in);
        
        conn = alta.getConnection();        
         
             try {
                 //Hacemos la sentencia para hacer la sentencia sql
              String sql = "INSERT INTO cliente(Nombre,Dirección,Teléfono,cedula,apellido) VALUES (?,?,?,?,?)";
                        psmt = conn.prepareStatement(sql);
                        // Establecer los valores en el PreparedStatement y los ordenamos para cargarlos en la base de datos
                        psmt.setString(1,nombre);
                        psmt.setString(2,direccion);
                        psmt.setInt(3,telefono);                       
                        psmt.setString(5,apellido);
                         psmt.setString(4,cedula);
                        psmt.executeUpdate();    
                        // Ejecutar la sentencia y obtener el número de filas afectadas
                        int filasAfectadas = psmt.executeUpdate();
                        //Si el numero de filas es mayor a 0 significa que se cargo los datos perfectamente
                        if(filasAfectadas>0){
                            //Suben los datos de manera normal 
                            conn.commit();
                            //hacemos un jpanel mostrando que el cliente se cargo con exito. 
                            JOptionPane.showMessageDialog(null, "Cliente registrado con exito");
                        // System.out.println("Filas insertadas: " + filasAfectadas);
                        }else{
                            //si no se afecto ninguna linea pasa al rolback donde y buelve todo a la normalidad. 
                            conn.rollback();
                        }
                        // Cerrar el PreparedStatement
                        psmt.close();       
        } catch (HeadlessException | SQLException e) {
        JOptionPane.showMessageDialog(null, e + "No se Logro registrar al cliente");
        }
               if(conn!=null){
               conn.close();
           }
        return resultado;
        
    }
    
 //Metodo 2
    public static boolean AltaClienteJuridico(int TIN,String Nom_Emp,String Dir_Emp,String Correo,int Telef) throws SQLException{
        boolean resulta=true;                
        
         Conexiónsql alta = new Conexiónsql();
         Connection conn = null;
        PreparedStatement psmt = null;
        Scanner a = new Scanner(System.in);
        
        conn = alta.getConnection();        
         
             try {
                 //Hacemos la sentencia para hacer la sentencia sql
              String sql = "INSERT INTO cliente_juridico(Tin,Nom_emp,Dir_emp,Correo,Telefono) VALUES (?,?,?,?,?)";
                        psmt = conn.prepareStatement(sql);
                        // Establecer los valores en el PreparedStatement y los ordenamos para cargarlos en la base de datos
                        psmt.setInt(1,TIN);
                        psmt.setString(2,Nom_Emp);
                        psmt.setString(3,Dir_Emp);                       
                        psmt.setString(4,Correo);
                         psmt.setInt(5,Telef);
                       // psmt.executeUpdate();    
                        // Ejecutar la sentencia y obtener el número de filas afectadas
                        int filasAfectadas = psmt.executeUpdate();
                        //Si el numero de filas es mayor a 0 significa que se cargo los datos perfectamente
                        if(filasAfectadas>0){
                            //Suben los datos de manera normal 
                            conn.commit();
                            //hacemos un jpanel mostrando que el cliente se cargo con exito. 
                            JOptionPane.showMessageDialog(null, "Cliente registrado con exito");
                        // System.out.println("Filas insertadas: " + filasAfectadas);
                        }else{
                            //si no se afecto ninguna linea pasa al rolback donde y buelve todo a la normalidad. 
                            conn.rollback();
                        }
                        // Cerrar el PreparedStatement
                        psmt.close();       
        } catch (HeadlessException | SQLException e) {
        JOptionPane.showMessageDialog(null, e + "No se Logro registrar al cliente");
        }
           if(conn!=null){
               conn.close();
           }
        return resulta;

    }
 
//Metodo 3
     public static boolean Mostrar_Clientes() throws SQLException{
             boolean resultado=true;
               Conexiónsql alta = new Conexiónsql();
         Connection conn = null;
        PreparedStatement psmt = null;
        
        conn = alta.getConnection();     
        try{ 
           // Preparar la consulta
            String sql = "SELECT Nombre, apellido FROM cliente WHERE ID_Cliente = 58";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            // Ejecutar la consulta
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                String nombre = rs.getString("nombre");
                String apellido = rs.getString("apellido");
                String mensaje = "Nombre: " + nombre + "\nApellido: " + apellido;
                JOptionPane.showMessageDialog(null, mensaje);
            } else {
                JOptionPane.showMessageDialog(null, "No se encontraron datos");
            }

            // Cerrar recursos
            rs.close();
            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
            if(conn!=null){
            conn.close();
        }    
    return resultado;
}
    
 //Futuro "metodo 4" digamos
  public static boolean Borrar_Datos_Tabla(){
      boolean resultado=false;
      //DELETE FROM nombre_de_la_tabla;
             
      return resultado;
  }  
 
//Cargar Conbox
// Cargar ComboBox
public ArrayList<String> cargarDatosEnComboBox() {
    Conexiónsql alta = new Conexiónsql();  // Instancia de la clase para obtener la conexión
    Connection conn = null;
    ArrayList<String> listaDeProductos = new ArrayList<>();

    try {
        // Inicializar la conexión a la base de datos
        conn = alta.getConnection();  // Asume que este método devuelve una conexión válida
        
        // Consulta SQL
        String sql = "SELECT Nombre FROM producto"; 
        PreparedStatement pstmt = conn.prepareStatement(sql);
        ResultSet rs = pstmt.executeQuery();

        // Recorre los resultados y agrega los datos al ArrayList
        while (rs.next()) {
            listaDeProductos.add(rs.getString("Nombre"));
        }
        
        // Cerrar ResultSet y PreparedStatement después de usarlos
        rs.close();
        pstmt.close();

    } catch (SQLException e) {
        e.printStackTrace();  // Manejo de errores
    } finally {
        try {
            // Cerrar la conexión si no es nula
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    return listaDeProductos; // Devolver los datos
}



  
//Futuro "Metodo 5 de editar"
  

//Futuro "Metodo 6 de buscar y eliminar"  


//Futuro "Metodo 7 de buscar"


//Futurp "Metodo 8 de subir empleado"
  
  
  
}
