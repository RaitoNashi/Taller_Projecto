/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.ArrayList;

/**
 *
 * @author 54255702
 */
public class Lista_productos {
    ArrayList<producto>lista_productos;

    public Lista_productos(){
        lista_productos=new ArrayList();
    }
    public void Agregar_Productos(producto s){
        lista_productos.add(s);
    }
}
