
package Main;

import Controlador.SceneManager;
import Modelo.Conexiónsql;
import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;

import javafx.stage.Stage;

public class Main extends Application {

         Conexiónsql alta = new Conexiónsql();
         
   public static void main(String[] args) {
        launch(args);
   }
   
    @Override
    public void start(Stage primaryStage) throws IOException {
        SceneManager sceneManager = SceneManager.getInstance();
        sceneManager.setPrimaryStage(primaryStage);
        sceneManager.changeScene("/Vista/Menu_Principal.fxml");
 
    }
   
}