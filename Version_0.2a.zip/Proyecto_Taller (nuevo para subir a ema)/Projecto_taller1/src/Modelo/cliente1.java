package Modelo;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author 54255702
 */

public class cliente1 {
    
    public static boolean Altacliente(String nombre, String direccion, String telefono, String apellido, String cedula) throws SQLException{
        boolean resultado=true;
        
         Conexiónsql alta = new Conexiónsql();
         Connection conn = null;
        PreparedStatement psmt = null;
        Scanner a = new Scanner(System.in);
        
        conn = alta.getConnection();        
         
             try {
                 //Hacemos la sentencia para hacer la sentencia sql
              String sql = "INSERT INTO cliente(Nombre,Dirección,Teléfono,cedula,apellido) VALUES (?,?,?,?,?)";
                        psmt = conn.prepareStatement(sql);
                        // Establecer los valores en el PreparedStatement y los ordenamos para cargarlos en la base de datos
                        psmt.setString(1,nombre);
                        psmt.setString(2,direccion);
                        psmt.setString(3,telefono);                       
                        psmt.setString(4,apellido);
                         psmt.setString(5,cedula);
                        psmt.executeUpdate();    
                        // Ejecutar la sentencia y obtener el número de filas afectadas
                        int filasAfectadas = psmt.executeUpdate();
                        //Si el numero de filas es mayor a 0 significa que se cargo los datos perfectamente
                        if(filasAfectadas>0){
                            //Suben los datos de manera normal 
                            conn.commit();
                            //hacemos un jpanel mostrando que el cliente se cargo con exito. 
                            JOptionPane.showMessageDialog(null, "Cliente registrado con exito");
                        // System.out.println("Filas insertadas: " + filasAfectadas);
                        }else{
                            //si no se afecto ninguna linea pasa al rolback donde y buelve todo a la normalidad. 
                            conn.rollback();
                        }
                        // Cerrar el PreparedStatement
                        psmt.close();       
        } catch (HeadlessException | SQLException e) {
        JOptionPane.showMessageDialog(null, e + "No se Logro registrar al cliente");
        }
        return resultado;
        
    }
    
    public static boolean BorrarCliente(String Nombre,String Telefono){
        boolean resulta=true;
            
       
        return false;  
    }
    
     
}
