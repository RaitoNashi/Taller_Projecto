/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador.Cliente;

import Controlador.SceneManager;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;
import javafx.scene.control.Button;

/**
 * FXML Controller class
 *
 * @author raito
 */
public class Dar_de_alta_clienteController implements Initializable {
    
    @FXML
    private TextArea ClienteNombre;
    
    @FXML
    private TextArea ClienteApellido;
    
    @FXML
    private TextArea ClienteCedula;
    
    @FXML
    private TextArea ClienteDireccion;
    
    @FXML
    private TextArea ClienteTelefono;
    
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    public void HandleVolverMenuCliente(ActionEvent event){
        SceneManager.getInstance().goBackMenuCliente();
    }
    
}
