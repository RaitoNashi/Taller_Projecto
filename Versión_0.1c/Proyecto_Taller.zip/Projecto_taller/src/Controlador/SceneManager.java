package Controlador;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Stack;

public class SceneManager {
    private static SceneManager instance;
    private Stage primaryStage;
    private Stack<String> sceneHistory = new Stack<>();

    private SceneManager() {}

    public static SceneManager getInstance() {
        if (instance == null) {
            instance = new SceneManager();
        }
        return instance;
    }

    public void setPrimaryStage(Stage stage) {
        this.primaryStage = stage;
    }

    public void changeScene(String fxmlFilePath) {
    if (fxmlFilePath == null || fxmlFilePath.isEmpty()) {
        throw new IllegalArgumentException("FXML file path cannot be null or empty");
    }

    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFilePath));
        Parent root = loader.load();
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    } catch (IOException e) {
        e.printStackTrace();
    }
}

    private String getCurrentSceneFilePath() {
        Scene currentScene = primaryStage.getScene();
        if (currentScene != null && currentScene.getUserData() != null) {
            return (String) currentScene.getUserData();
        }
        return null;
    }
    
    public void goBack() {
        SceneManager.getInstance().changeScene("/Vista/Menu_Principal.fxml");
    }
    
    public void goBackMenuCliente(){
        SceneManager.getInstance().changeScene("/Vista/Cliente/Cliente_Menu.fxml");
    }
}
