package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author 54255702
 */

public class ConVenta{
    
    public static boolean RealizarCompra(String idVenta,String idCantidad,String idProducto,String idCedula) throws SQLException{
        boolean resultado=true;
         Conexiónsql alta = new Conexiónsql();
         Connection conn = null;
        PreparedStatement psmt = null;
        Scanner a = new Scanner(System.in);
        
        conn = alta.getConnection();
          // Preparar la sentencia SQL
                        String sql = "INSERT INTO cliente (ID_Venta Total) VALUES (?,?)";
                        psmt = conn.prepareStatement(sql);
                        // Establecer los valores en el PreparedStatement
                        psmt.setString(1, idVenta);
                      //  psmt.setString(2, idCantidad);
                       // psmt.setString(3, idProducto);
                    //    psmt.setString(2, Fecha);
                        //año,mes,dia
                      //  psmt.setString(3, );
                        // Ejecutar la sentencia y obtener el número de filas afectadas
                        int filasAfectadas = psmt.executeUpdate();
                        if(filasAfectadas>0){
                            conn.commit();
                        System.out.println("Filas insertadas: " + filasAfectadas);
                        }else{
                            conn.rollback();
                        }
                        // Cerrar el PreparedStatement
                     psmt.close();
    
        return resultado;
        
    }
    
    public static boolean BorrarCliente(String Nombre,String Telefono){
        boolean resulta=true;
        
        
        
        
        
        
        return false;  
    }
}
    
  
    
