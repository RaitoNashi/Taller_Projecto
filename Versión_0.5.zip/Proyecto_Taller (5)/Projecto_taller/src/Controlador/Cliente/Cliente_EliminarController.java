/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador.Cliente;

import Controlador.Inventario.InventarioController;
import Controlador.SceneManager;
import Modelo.Cliente1;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import java.lang.String;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.control.TableCell;

/**
 * FXML Controller class
 *
 * @author raito
 */
public class Cliente_EliminarController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
    public ArrayList<ArrayList<Object>> ClientesLista = new ArrayList<>();
    
    public Modelo.Cliente1 cli1=new Modelo.Cliente1();
    
    private String cedulaSeleccionada;  // O cambiar a 'nombreSeleccionado' si prefieres
    
    @FXML
    private TextField Abuscar;

    @FXML
    private TableView<ArrayList<Object>> tablaEliminarCliente;

    @FXML
    private TableColumn<ArrayList<Object>,String> CedCli;

    @FXML
    private TableColumn<ArrayList<Object>,String> NomClie;

    @FXML
    private TableColumn<ArrayList<Object>,String> ApeClie;

    @FXML
    private TableColumn<ArrayList<Object>,String> DirClie;

    @FXML
    private TableColumn<ArrayList<Object>,Integer> TelClie;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
      // Configura las columnas para obtener los datos correctos de cada índice en el ArrayList
        // Realizar casting explícito para cada columna según su tipo
    CedCli.setCellValueFactory(data -> new SimpleObjectProperty<>((String) data.getValue().get(0)));
    NomClie.setCellValueFactory(data -> new SimpleObjectProperty<>((String) data.getValue().get(1)));
    ApeClie.setCellValueFactory(data -> new SimpleObjectProperty<>((String) data.getValue().get(2)));
    DirClie.setCellValueFactory(data -> new SimpleObjectProperty<>((String) data.getValue().get(3)));
    TelClie.setCellValueFactory(data -> new SimpleObjectProperty<>((Integer) data.getValue().get(4)));
    
     CedCli.setCellFactory(column -> new TableCell<ArrayList<Object>, String>() {
        @Override
        protected void updateItem(String item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null) {
                setText(null);
            } else {
                setText(item.toString()); // Muestra el valor sin decimales
                setStyle("-fx-alignment: CENTER-RIGHT;"); // Alinea el texto a la derecha
            }
        }
    });
     
      // Alinear la columna ColStock a la derecha
    TelClie.setCellFactory(column -> new TableCell<ArrayList<Object>, Integer>() {
        @Override
        protected void updateItem(Integer item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null) {
                setText(null);
            } else {
                setText(item.toString()); // Muestra el valor sin decimales
                setStyle("-fx-alignment: CENTER-RIGHT;"); // Alinea el texto a la derecha
            }
        }
    });
    
     // Listener para la selección de la tabla
    tablaEliminarCliente.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
        if (newValue != null) {
            // Suponiendo que la cédula está en la primera posición del ArrayList
            cedulaSeleccionada = (String) newValue.get(0); // O usar newValue.get(1) para el nombre
            System.out.println("Cédula seleccionada: " + cedulaSeleccionada);
        }
    });
    
    }    
    

    @FXML
public void aceptar(ActionEvent event) throws SQLException {
    String nombre = Abuscar.getText();
    ArrayList<ArrayList<Object>> ClientesLista = cli1.TraerCliente(nombre);
    cargarTabla(ClientesLista);  // Llamar a cargarTabla con los resultados de la consulta
}

      @FXML
    void eliminarcliente(ActionEvent event) throws SQLException {
     if (cedulaSeleccionada != null) {
        // Lógica para eliminar el cliente con la cédula seleccionada
        System.out.println("Eliminar cliente con cédula: " + cedulaSeleccionada);
        // Aquí llamamos al método para eliminar cliente       
        String exit=cli1.EliminarClienteDeTabla(cedulaSeleccionada);
        System.out.println(exit);
        
        // Actualizar la tabla después de la eliminación
        String nombre = Abuscar.getText();  // Obtener el texto del campo de búsqueda para actualizar
        ArrayList<ArrayList<Object>> ClienteActualizado = cli1.TraerCliente(nombre);  // Volver a buscar clientes
        cargarTabla(ClienteActualizado);  // Llamar a cargarTabla con los nuevos resultados
    } else {
        System.out.println("No se ha seleccionado ningún cliente.");
    }
    }
    
   

public void cargarTabla(ArrayList<ArrayList<Object>> ClienteActualizado) {
    tablaEliminarCliente.getItems().clear();
    tablaEliminarCliente.getItems().addAll(ClienteActualizado);
}  

    public void HandleVolverMenuCliente(ActionEvent event){
        SceneManager.getInstance().goBackMenuCliente();
    }

     
    public Cliente1 getCli1() {
        return cli1;
    }
     
    public TextField getAbuscar() {
        return Abuscar;
    }

    public TableColumn<ArrayList<Object>, String> getCedCli() {
        return CedCli;
    }

    public TableColumn<ArrayList<Object>, String> getNomClie() {
        return NomClie;
    }

    public TableColumn<ArrayList<Object>, String> getApeClie() {
        return ApeClie;
    }

    public TableColumn<ArrayList<Object>, String> getDirClie() {
        return DirClie;
    }

    public TableColumn<ArrayList<Object>, Integer> getTelClie() {
        return TelClie;
    }
    
    
}

