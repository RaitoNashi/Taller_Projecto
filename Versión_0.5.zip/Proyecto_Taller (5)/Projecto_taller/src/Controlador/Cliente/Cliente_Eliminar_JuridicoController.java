package Controlador.Cliente;

import Controlador.SceneManager;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleObjectProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class Cliente_Eliminar_JuridicoController implements Initializable {

    public ArrayList<ArrayList<Object>> productos = new ArrayList<>();
    
    public Modelo.Cliente1 cli1=new Modelo.Cliente1();
   
    public Integer RutSeleccionado;
   
    @FXML
    private TextField AbusJur;

    @FXML
    private TableView<ArrayList<Object>> TabClieJurElim;

    @FXML
    private TableColumn<ArrayList<Object>,Integer> RUT;

    @FXML
    private TableColumn<ArrayList<Object>,String> NomEmp;

    @FXML
    private TableColumn<ArrayList<Object>,String> Dir;

    @FXML
    private TableColumn<ArrayList<Object>,String> Cor;

    @FXML
    private TableColumn<ArrayList<Object>,Integer> Tel;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
     // Configura las columnas para obtener los datos correctos de cada índice en el ArrayList
        // Realizar casting explícito para cada columna según su tipo
    RUT.setCellValueFactory(data -> new SimpleObjectProperty<>((Integer) data.getValue().get(0)));
    NomEmp.setCellValueFactory(data -> new SimpleObjectProperty<>((String) data.getValue().get(1)));
    Dir.setCellValueFactory(data -> new SimpleObjectProperty<>((String) data.getValue().get(2)));
    Cor.setCellValueFactory(data -> new SimpleObjectProperty<>((String) data.getValue().get(3)));
    Tel.setCellValueFactory(data -> new SimpleObjectProperty<>((Integer) data.getValue().get(4)));
    
     RUT.setCellFactory(column -> new TableCell<ArrayList<Object>, Integer>() {
        @Override
        protected void updateItem(Integer item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null) {
                setText(null);
            } else {
                setText(item.toString()); // Muestra el valor sin decimales
                setStyle("-fx-alignment: CENTER-RIGHT;"); // Alinea el texto a la derecha
            }
        }
    });
     
      Tel.setCellFactory(column -> new TableCell<ArrayList<Object>, Integer>() {
        @Override
        protected void updateItem(Integer item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null) {
                setText(null);
            } else {
                setText(item.toString()); // Muestra el valor sin decimales
                setStyle("-fx-alignment: CENTER-RIGHT;"); // Alinea el texto a la derecha
            }
        }
    });
     // Añadir listener a la selección de elementos
    TabClieJurElim.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
        if (newValue != null) {
            RutSeleccionado = (int) newValue.get(0); // Obtener la cédula seleccionada
            System.out.println("Cédula seleccionada: " + RutSeleccionado);
        }
    });
    }
    
    @FXML
    void Aceptar(ActionEvent event) throws SQLException {
    String nombre = AbusJur.getText();
    ArrayList<ArrayList<Object>> clienteEliminar = cli1.TraerClienteJuridico(nombre);
    cargarTabla(clienteEliminar);  // Llamar a cargarTabla con los resultados de la consulta

    }
    
    @FXML
    void ElimCliJurid(ActionEvent event) throws SQLException {
        if(RutSeleccionado != null){
        //Logica para eliminar cliente juridico con el RUT
            System.out.println("Cliente juridico a eliminar con el rut:"+RutSeleccionado);
        //Aca se llama al método para eliminar el cliente juridico
        String exit=cli1.EliminarClienteDeTablaju(RutSeleccionado);
            System.out.println(exit);
        
        // Actualizar la tabla después de la eliminación
        String nombre = AbusJur.getText();  // Obtener el texto del campo de búsqueda para actualizar
        ArrayList<ArrayList<Object>> LisClieElim = cli1.TraerClienteJuridico(exit);  // Volver a buscar clientes
        cargarTabla(LisClieElim);  // Llamar a cargarTabla con los nuevos resultados
   
        }else{
        System.out.println("No se ha seleccionado ningún cliente.");
       
        }
        
    }

    public void cargarTabla(ArrayList<ArrayList<Object>> ListaClie) {
        TabClieJurElim.getItems().clear();
        TabClieJurElim.getItems().addAll(ListaClie);
} 
    
    
    @FXML
    void HandleVolverMenuCliente(ActionEvent event) {
         SceneManager.getInstance().goBackMenuCliente();
    }

    
    
    
    
    
    public TextField getAbusJur() {
        return AbusJur;
    }

    public TableView<?> getTabClieJurElim() {
        return TabClieJurElim;
    }

    public TableColumn<?, ?> getRUT() {
        return RUT;
    }

    public TableColumn<?, ?> getNomEmp() {
        return NomEmp;
    }

    public TableColumn<?, ?> getDir() {
        return Dir;
    }

    public TableColumn<?, ?> getCor() {
        return Cor;
    }

    public TableColumn<?, ?> getTel() {
        return Tel;
    }

    
    
}
