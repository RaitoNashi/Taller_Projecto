/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador.Cliente;

import Controlador.SceneManager;
import Modelo.Cliente1;
import Modelo.Conexiónsql;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;
import javafx.scene.control.Button;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 * FXML Controller class
 *
 * @author raito
 */
public class Dar_de_alta_clienteController implements Initializable {
    
    @FXML
    private TextArea ClienteNombre;
    
    @FXML
    private TextArea ClienteApellido;
    
    @FXML
    private TextArea ClienteCedula;
    
    @FXML
    private TextArea ClienteDireccion;
    
    @FXML
    private TextArea ClienteTelefono;
    
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    public void HandleVolverMenuCliente(ActionEvent event){
        SceneManager.getInstance().goBackMenuCliente();
    }
    
    @FXML
    public void HandleEnviar(ActionEvent event)throws SQLException{
            Modelo.Cliente1 ClienteEnvio = new Cliente1();
            boolean resultado=true;
            int telefono=0;
            // Verificar que los datos no esten vacios
            String nombre=ClienteNombre.getText();
            if(nombre.isEmpty()){
               // Crear y agregar un JLabel al panel
             JOptionPane.showMessageDialog(null, "vos sabes que ese nombre nunca en mi perra vida lo escuche");
                return;
            }
            String direccion=ClienteDireccion.getText();
            if(direccion.isEmpty()){
                // Crear y agregar un JLabel al panel
            JOptionPane.showMessageDialog(null, "Sabes que esa direccion no la conozco, o no la conozco o no me la dijiste");
            return;
            }
                            
            String apellido=ClienteApellido.getText();
            if(apellido.isEmpty()){
                // Crear y agregar un JLabel al panel
            JOptionPane.showMessageDialog(null, "Campo apellido dudoso o vacio");
            return;
            }
            String cedula=ClienteCedula.getText();
            if(cedula.isEmpty()){
                // Crear y agregar un JLabel al panel
            JOptionPane.showMessageDialog(null, "Esa cedula no me suena, capas no la ingresaste");
            }
            String t=ClienteTelefono.getText();     
            
            if(t.length()<9){
                // Crear y agregar un JLabel al panel
             JOptionPane.showMessageDialog(null, "Damelo otra vez al numero porque no lo tengo registrado en Watsapp");
            return;
            }else{
                telefono=Integer.parseInt(t);
            }
            resultado=Modelo.Cliente1.Altacliente(nombre, direccion, telefono, apellido, cedula);
        }
    
    
}
