/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador.Cliente;

import Controlador.SceneManager;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;


/**
 * FXML Controller class
 *
 * @author raito
 */
public class Menú_clienteController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
    }    
    
    public void handleClienteFisico(ActionEvent event){
        SceneManager.getInstance().changeScene("/Vista/Cliente/Cliente_Dar_De_Alta.fxml");
    }
    
    public void handleClienteJuridico(ActionEvent event){
        SceneManager.getInstance().changeScene("/Vista/Cliente/Cliente_Dar_De_Alta_Juridico.fxml");
    }
    
    public void handleCambiarDatos(ActionEvent event){
        SceneManager.getInstance().changeScene("/Vista/Cliente/Cliente_Cambiar_Datos.fxml");
    } 
    
    public void handleCambiarDatosJuridico(ActionEvent event){
        SceneManager.getInstance().changeScene("/Vista/Cliente/Cliente_Cambiar_Datos_Juridico.fxml");
    }  
    
    public void handleEliminar(ActionEvent event){
        SceneManager.getInstance().changeScene("/Vista/Cliente/Cliente_Eliminar.fxml");
    }    
    
    public void handleEliminarju(ActionEvent event) {
         SceneManager.getInstance().changeScene("/Vista/Cliente/Cliente_Eliminar_Juridico.fxml");
    }
    
    public void MostrarMenuPrincipal(){
        SceneManager.getInstance().goBack();
    }
    
    
}
