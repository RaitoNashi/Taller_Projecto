package Controlador.Empleado;

import Controlador.SceneManager;
import Modelo.Cliente1;
import Modelo.Empleado;
import Modelo.Sucursal;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
/**
 * FXML Controller class
 *
 * @author raito
 */
public class EmpleadoAgregarController implements Initializable {
    public String nom="",cargo="",dire="",depar="",sucur="";
    public int tel;
    
    public  Modelo.Sucursal suc= new Sucursal();
    
    @FXML
    private TextField EmpleadoNombre;

    @FXML
    private TextField EmpleadoCargo;

    @FXML
    private TextField EmpleadoTel;

    @FXML
    private TextField EmpleadoDir;

    @FXML
    private TextField EmpleadoDepar;

    @FXML
    private TextField EmpleadoSucursal;

        
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
    }    
    
      @FXML
    void agregar(ActionEvent event) throws SQLException {
         Modelo.Empleado emp = new Empleado();
        String idsuc="";
        int id;
        nom=EmpleadoNombre.getText();
        cargo=EmpleadoCargo.getText();
        dire=EmpleadoDir.getText();
        depar=EmpleadoDepar.getText();
        sucur=EmpleadoSucursal.getText();
        String te=EmpleadoTel.getText();
        tel=Integer.parseInt(te);
         idsuc=Modelo.Sucursal.BuscarIDSucu(sucur);
         id=Integer.parseInt(idsuc);
          emp.AgregarEmpleado(nom,cargo,tel,dire,depar,id);
    }
    //String Nombre,String Cargo,int Telefono,String Direccion,String Departamento,int ID_Sucursal
    
        public void IrMenuEmpleado(){
        SceneManager.getInstance().goBackMenuEmpleado();
    }
}
