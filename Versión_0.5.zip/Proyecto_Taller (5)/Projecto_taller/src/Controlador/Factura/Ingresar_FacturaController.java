package Controlador.Factura;

import Controlador.SceneManager;
import Modelo.Cliente1;
import Modelo.Conexiónsql;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import java.util.ArrayList;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import java.time.LocalDate;
import javafx.scene.control.DatePicker;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javafx.scene.control.cell.PropertyValueFactory;
import java.lang.Math;
import java.lang.String;
import Modelo.BuscarDeProducto;
import Modelo.FacturaModelo;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableCell;
import javafx.stage.Stage;
//nuevo
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;


public class Ingresar_FacturaController implements Initializable {
    public Modelo.FacturaModelo fm=new FacturaModelo(); 
    public int auxsubtotal = 0;
    public int cantidadprod;
    public double unitpr;
    public double subtoto;
    public int auxiliar;
    public String au;
    public boolean cargo = true;
    public String nombreProducto;
    public String prod;
    int auxiliarCantidad;
    public String prodddd;
    @FXML
    public BuscarDeProducto buscProdCon;
    @FXML
    public ComboBox<String> conxxx;
    @FXML
    public ComboBox<String> ConClientes;
    @FXML
    public ComboBox<String> conEmpleado;
    @FXML
    private ComboBox<String> conSucursal;
    @FXML
    public TableView<CargarTabla> tableView;
    @FXML
    public TableColumn<CargarTabla, String> Produco;
    @FXML
    public TableColumn<CargarTabla, Integer> Cantid;
    @FXML
    public TableColumn<CargarTabla, Double> UbitPrecio;
    @FXML
    public TableColumn<CargarTabla, Double> SubTotal;
    @FXML
    public TextField IDVenta;
    @FXML
    public TextField IDProducto;
    @FXML
    public TextField CantProducto;
    @FXML
    public TextField Cedula;
    @FXML
    public DatePicker fecha;
    @FXML
    public Button agregarr;
    @FXML
    public TextField TOTAL;
    @FXML
    public TextField buscProd;

    public ArrayList<CargarTabla> ListaDatos = new ArrayList<>();

// ArrayList para almacenar el historial
    public ArrayList<CargarTabla> historialDatos = new ArrayList<>();

    public Ingresar_FacturaController() { }

    public Ingresar_FacturaController(BuscarDeProducto buscarDeProducto) {
        this.buscProdCon = buscarDeProducto;
    }

    public Ingresar_FacturaController(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Conexiónsql alta = new Conexiónsql();
        llenarComboBoxCliente();
        llenarComboBoxEmpleado();
        llenarComboBoxSucursal();
        Produco.setCellValueFactory(new PropertyValueFactory<>("producto"));
        Cantid.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
        UbitPrecio.setCellValueFactory(new PropertyValueFactory<>("unitprecio"));
        SubTotal.setCellValueFactory(new PropertyValueFactory<>("subTotal"));

        
          // Alinear la columna ColStock a la derecha
    Cantid.setCellFactory(column -> new TableCell<CargarTabla, Integer>() {
        @Override
        protected void updateItem(Integer item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null) {
                setText(null);
            } else {
                setText(item.toString()); // Muestra el valor sin decimales
                setStyle("-fx-alignment: CENTER-RIGHT;"); // Alinea el texto a la derecha
            }
        }
    });
    
    UbitPrecio.setCellFactory(column -> new TableCell<CargarTabla, Double>() {
        @Override
        protected void updateItem(Double item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null) {
                setText(null);
            } else {
                setText(item.toString()); // Muestra el valor sin decimales
                setStyle("-fx-alignment: CENTER-RIGHT;"); // Alinea el texto a la derecha
            }
        }
    });

    SubTotal.setCellFactory(column -> new TableCell<CargarTabla, Double>() {
        @Override
        protected void updateItem(Double item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null) {
                setText(null);
            } else {
                setText(item.toString()); // Muestra el valor sin decimales
                setStyle("-fx-alignment: CENTER-RIGHT;"); // Alinea el texto a la derecha
            }
        }
    });
        
    
        au="";
        auxiliarCantidad=0;
        cantidadprod = 0;
        unitpr = 0.0;
        nombreProducto = "";
        prodddd = "";
    
    }

    @FXML
    public void MostrarMenuPrincipal() {
        SceneManager.getInstance().goBack();
    }    
   @FXML


public void MostrarPopUp() throws SQLException {
    boolean cargoCorrectamente = true;
      int id_venta=fm.TraerIDMaxDeFactura();  // Obtener el id de la venta para que todos los productos lo usen
// historialDatos.addAll(new ArrayList<>(ListaDatos));
    
     for (CargarTabla item : historialDatos) {
        System.out.println("Producto: " + item.getProducto() +
                           ", Cantidad: " + item.getCantidad() +
                           ", Precio Unitario: " + item.getUnitprecio() +
                           ", Subtotal: " + item.getSubTotal());
    }
     
    for (CargarTabla item : historialDatos){
        boolean resultado = fm.CardarDetalleVentna(
            id_venta,
            getAuxiliar(),                // ID del producto
            item.getCantidad(),           // Cantidad
            (float) item.getUnitprecio(), // Precio unitario
            (int) item.getSubTotal(),     // Subtotal
            item.getProducto()            // Nombre del producto
        );

        // Si alguna inserción falla, establecemos `cargoCorrectamente` en `false`
        if (!resultado) {
            cargoCorrectamente = false;
            System.out.println("Error al subir el producto: " + item.getProducto());
        }
    }

    // Mensaje final dependiendo del resultado de las cargas
    if (cargoCorrectamente) {
        System.out.println("Todos los datos se subieron correctamente.");
    } else {
        System.out.println("Ocurrió un error al subir algunos de los datos.");
    }
}

    public void cargarDatos(String prueba) throws SQLException {
        prodddd = prueba;
        ListaDatos.clear();
        
     //   System.out.println("EMAAAAAA" + prueba);
        if (prodddd.isEmpty()) {
            System.out.println("No se ha seleccionado ningún producto.");
            return;
        }

        try {
            cantidadprod = Integer.parseInt(CantProducto.getText());
            auxiliarCantidad+=cantidadprod;
            System.out.println(auxiliarCantidad);                   
        } catch (NumberFormatException e) {
            System.out.println("La cantidad ingresada no es un número válido.");
            return;
        }

        try {
            unitpr = Modelo.FacturaModelo.TraerPrecio(prodddd);
        } catch (SQLException e) {
            System.out.println("Error al obtener el precio: " + e.getMessage());
            return;
        }

        subtoto = unitpr * cantidadprod;
        ListaDatos.add(new CargarTabla(prodddd, cantidadprod, unitpr, subtoto));
        tableView.getItems().addAll(ListaDatos);

        // Copiamos el contenido de ListaDatos a historialDatos
        historialDatos.addAll(new ArrayList<>(ListaDatos));
    
        int u = (int) Math.round(subtoto);
        auxsubtotal += u;
        TOTAL.setText(String.valueOf(auxsubtotal));

        au = Modelo.FacturaModelo.TraerIDProd(prodddd);             
        if (au != null) {
            auxiliar = Integer.parseInt(au);
        } else {
            System.out.println("No se pudo obtener el ID del producto.");
        }
    }

    
    public void limpiarCampos() {
        IDVenta.clear();
        IDProducto.clear();
        CantProducto.clear();
        Cedula.clear();
    }
    
        public void llenarComboBoxSucursal() {
        ArrayList<String> listaDeSucursales = fm.llenarComboBoxSucursal();
        conSucursal.getItems().clear();
        conSucursal.getItems().addAll(listaDeSucursales);
    }
        
    public void llenarComboBoxCliente() {
        ArrayList<String> listaDeClientes = fm.cargarDatosEnComboBoxCliente();
        ConClientes.getItems().clear();
        ConClientes.getItems().addAll(listaDeClientes);
    }

    public void llenarComboBoxEmpleado() {
        ArrayList<String> listaDeEmpleado = fm.llenarComboBoxEmpleado();
        conEmpleado.getItems().clear();
        conEmpleado.getItems().addAll(listaDeEmpleado);
    }

    @FXML
    public void agregar(ActionEvent event) throws SQLException {
        double fprecio;
        System.out.println("IMPRECIONABLE: " + prod);

        if (prod != null && !prod.isEmpty()) {
            fprecio = Modelo.FacturaModelo.TraerPrecio(prod);
            System.out.println("Precio obtenido: " + fprecio);
            String prueba = buscProdCon.getMensaje();
            cargarDatos(prueba);
        } else {
            System.out.println("No se ha seleccionado ningún producto.");
        }
    }

    public void buscar(ActionEvent event) throws SQLException, IOException {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Vista/Facturación/Vista_Buscador_Producto.fxml"));
            Parent root = loader.load();

            // Obtener el controlador del buscador y pasar la instancia de Ingresar_FacturaController
            BuscarDeProducto controller = loader.getController();
            controller.setIngresarFacturaController(this); // Método que debes crear en BuscarDeProducto para setear la referencia

            Stage nuevoStage = new Stage();
            nuevoStage.setScene(new Scene(root));
            nuevoStage.setTitle("Buscar Producto");
            nuevoStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Clase auxiliar `CargarTabla`
    public static class CargarTabla {
        private final String producto;
        private final int cantidad;
        private final double unitprecio;
        private final double subTotal;

        public CargarTabla(String producto, int cantidad, double unitprecio, double subTotal) {
            this.producto = producto;
            this.cantidad = cantidad;
            this.unitprecio = unitprecio;
            this.subTotal = subTotal;
        }

        public String getProducto() {
            return producto;
        }

        public int getCantidad() {
            return cantidad;
        }

        public double getUnitprecio() {
            return unitprecio;
        }

        public double getSubTotal() {
            return subTotal;
        }
       
    
    }

    public int getCantidadprod() {
        return cantidadprod;
    }

    public double getUnitpr() {
        return unitpr;
    }
   
    
   public String getAu() {
        return au;
    }

    public int getAuxiliarCantidad() {
        return auxiliarCantidad;
    }

    public String getProdddd() {
        return prodddd;
    }

    public double getSubtoto() {
        return subtoto;
    }

    public int getAuxiliar() {
        return auxiliar;
    }
  
    
}



