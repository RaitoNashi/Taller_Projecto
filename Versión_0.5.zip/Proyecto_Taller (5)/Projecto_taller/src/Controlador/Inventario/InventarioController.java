package Controlador.Inventario;


import Controlador.SceneManager;
import Modelo.Cliente1;
import Modelo.Conexiónsql;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;

import java.net.URL;
import java.sql.*;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.text.TextAlignment;

public class InventarioController implements Initializable {

     public Modelo.Cliente1 cli1=new Modelo.Cliente1();
     
    @FXML
    private TableView<ArrayList<Object>> tableView;

    @FXML
    private TableColumn<ArrayList<Object>, Integer> colID;
    @FXML
    private TableColumn<ArrayList<Object>, String> ColNom;
    @FXML
    private TableColumn<ArrayList<Object>, String> ColDesc;
    @FXML
    private TableColumn<ArrayList<Object>, Float> ColPrecio;
    @FXML
    private TableColumn<ArrayList<Object>, Integer> ColStock;
    
    
  @Override
    public void initialize(URL url, ResourceBundle rb) {
        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // Configuración de las columnas
        colID.setCellValueFactory(cellData -> new SimpleObjectProperty<>((Integer) cellData.getValue().get(0)));
        ColNom.setCellValueFactory(cellData -> new SimpleObjectProperty<>((String) cellData.getValue().get(1)));
        ColDesc.setCellValueFactory(cellData -> new SimpleObjectProperty<>((String) cellData.getValue().get(2)));
        ColPrecio.setCellValueFactory(cellData -> new SimpleObjectProperty<>((Float) cellData.getValue().get(3)));
        ColStock.setCellValueFactory(cellData -> new SimpleObjectProperty<>((Integer) cellData.getValue().get(4)));
    
        // Alinear la columna ColPrecio a la derecha
    ColPrecio.setCellFactory(column -> new TableCell<ArrayList<Object>, Float>() {
        @Override
        protected void updateItem(Float item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null) {
                setText(null);
            } else {
                setText(String.format("%.2f", item)); // Formatea el valor
                setStyle("-fx-alignment: CENTER-RIGHT;"); // Alinea el texto a la derecha
            }
        }
    });
    
     // Alinear la columna ColStock a la derecha
    ColStock.setCellFactory(column -> new TableCell<ArrayList<Object>, Integer>() {
        @Override
        protected void updateItem(Integer item, boolean empty) {
            super.updateItem(item, empty);
            if (empty || item == null) {
                setText(null);
            } else {
                setText(item.toString()); // Muestra el valor sin decimales
                setStyle("-fx-alignment: CENTER-RIGHT;"); // Alinea el texto a la derecha
            }
        }
    });
    
        
        Platform.runLater(() -> {
        try {
            ArrayList<ArrayList<Object>> productos = cli1.cargarProductos();
            if (productos != null && !productos.isEmpty()) {
                tableView.getItems().clear();
                tableView.getItems().addAll(productos);
            } else {
                // Mostrar un mensaje de error al usuario si no hay datos
                System.out.println("No se encontraron productos.");
            }
        } catch (SQLException ex) {
            Logger.getLogger(InventarioController.class.getName()).log(Level.SEVERE, null, ex);
            // Mostrar un mensaje de error al usuario
        }
    });
   /* 
  ColPrecio.setCellValueFactory(cellData -> {
    try {
        Float precio = (Float) cellData.getValue().get(3);
        String formattedPrecio = String.format("%.2f", precio);
        Float precioFormateado = Float.valueOf(formattedPrecio); // Convert to Float
        return new SimpleObjectProperty<>(precioFormateado);
    } catch (NullPointerException | IndexOutOfBoundsException e) {
        return new SimpleObjectProperty<>("N/A"); // Handle null or invalid values
    }
});
*/
    }    

    public Cliente1 getCli1() {
        return cli1;
    }

    public TableView<ArrayList<Object>> getTableView() {
        return tableView;
    }

    public TableColumn<ArrayList<Object>, Integer> getColID() {
        return colID;
    }

    public TableColumn<ArrayList<Object>, String> getColNom() {
        return ColNom;
    }

    public TableColumn<ArrayList<Object>, String> getColDesc() {
        return ColDesc;
    }

    public TableColumn<ArrayList<Object>, Float> getColPrecio() {
        return ColPrecio;
    }

    public TableColumn<ArrayList<Object>, Integer> getColStock() {
        return ColStock;
    }
    
    
    
    public void cargarDatos(ArrayList<ArrayList<Object>> productos) {
        tableView.getItems().clear();
        tableView.getItems().addAll(productos);
    }
    
     public void MostrarMenuPrincipal(){
        SceneManager.getInstance().goBack();
     }
}
/*
    private Callback<TableColumn<ArrayList<Object>, Object>, TableCell<ArrayList<Object>, Object>> createFormattedCellFactory(String format) {
        return column -> new TableCell<>() {
            @Override
            protected void updateItem(Object item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : String.format(format, item));
                setStyle("-fx-alignment: CENTER-RIGHT;");
            }
        };
    }

   public void cargarProductos() {
    ArrayList<ArrayList<Object>> productos = new ArrayList<>();
    
    // Conexión a la base de datos
    Conexiónsql alta = new Conexiónsql();
    Connection conn = null;
    PreparedStatement psmt = null;
    ResultSet rs = null;

    try {
        // Obtener la conexión
        conn = alta.getConnection();
        
        if (conn == null) {
            System.err.println("Error: No se pudo establecer la conexión con la base de datos.");
            return;
        }

        // Preparar la consulta SQL
        String sql = "SELECT * FROM producto";
        psmt = conn.prepareStatement(sql);
        
        // Ejecutar la consulta y obtener el resultado
        rs = psmt.executeQuery();

        if (rs == null) {
            System.err.println("Error: No se recibió ningún resultado de la consulta SQL.");
            return;
        }

        // Procesar el resultado de la consulta
        while (rs.next()) {
            ArrayList<Object> fila = new ArrayList<>();
            fila.add(rs.getInt("ID_Producto"));  // ID
            fila.add(rs.getString("Nombre"));     // Nombre
            fila.add(rs.getString("Descripcion")); // Descripción
            fila.add(rs.getFloat("Precio"));      // Precio
            fila.add(rs.getInt("Stock"));         // Stock
            
            productos.add(fila);
        }
        
    } catch (SQLException e) {
        System.err.println("Error al conectar a la base de datos: " + e.getMessage());
    } finally {
        // Cerrar recursos
        try {
            if (rs != null) rs.close();
            if (psmt != null) psmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            System.err.println("Error al cerrar recursos: " + e.getMessage());
        }
    }

    cargarDatos(productos);
}

    public void cargarDatos(ArrayList<ArrayList<Object>> productos) {
        tableView.getItems().clear();
        tableView.getItems().addAll(productos);
    }

    public void MostrarMenuPrincipal(){
        SceneManager.getInstance().goBack();
    }*/
   /*corregido
    ColPrecio.setCellValueFactory(cellData -> new SimpleDoubleProperty(((Producto) cellData.getValue()).getPrecio()));
ColPrecio.setCellFactory(column -> {
    TableCell<ArrayList<Object>, Double> cell = new TableCell<>();
    cell.setTextAlignment(TextAlignment.RIGHT);
    cell.setText(String.format("%.2f", cell.getItem()));
    return cell;
});
        */