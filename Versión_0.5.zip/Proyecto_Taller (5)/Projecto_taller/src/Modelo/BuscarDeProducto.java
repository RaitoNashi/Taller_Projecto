/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Modelo;

import Controlador.SceneManager;
import Controlador.Factura.Ingresar_FacturaController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import java.sql.*;
import java.util.ArrayList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.SelectionMode;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;


public class BuscarDeProducto {
   // Ingresar_FacturaController IngFac=new Ingresar_FacturaController();
    
    public  Ingresar_FacturaController IngFac = new Ingresar_FacturaController("Nombre del Producto");
    
    @FXML
    public TextField productoTextField;
    @FXML
    public TableView<BuscarDeProducto> tablaprueba;
    @FXML
    public TableColumn<BuscarDeProducto, String> NomProd;
    @FXML
    public TableColumn<BuscarDeProducto, String> DescProd;

    public ObservableList<BuscarDeProducto> listaProductos = FXCollections.observableArrayList();
    
    public Ingresar_FacturaController ifc;
    public String nombre;
    public String descripcion;
    public String mensaje;
    
     private Ingresar_FacturaController ingresarFacturaController;
    
      public BuscarDeProducto() {
          //
    }
     
       public BuscarDeProducto(Ingresar_FacturaController ingresarFacturaController) {
        this.ingresarFacturaController = ingresarFacturaController;
    }
       
    public void setIngresarFacturaController(Ingresar_FacturaController controller) {
    this.IngFac = controller;
}
    public void initialize() {
        
        // Configurar las columnas de la tabla ingresarFacturaController.buscProd.setText(mensaje);
        NomProd.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getNombre()));
        DescProd.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getDescripcion()));
       
        // Permitir la selección de una sola fila en la tabla
        tablaprueba.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

        // Añadir un listener para detectar cuando el usuario selecciona una fila
        tablaprueba.setOnMouseClicked(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent event) {
                // Verificar que hay un producto seleccionado
                BuscarDeProducto productoSeleccionado = tablaprueba.getSelectionModel().getSelectedItem();
                if (productoSeleccionado != null) {
                    // Mostrar el producto seleccionado en un JOptionPane (Alert en JavaFX)
                    mostrarProductoSeleccionado(productoSeleccionado);
                }
            }
        });
    }

    @FXML
    public void buscarProducto() {
        String nombre = productoTextField.getText();
        listaProductos.clear(); // Limpiar la lista antes de añadir nuevos resultados

        // Simulación de búsqueda en la base de datos
        ArrayList<BuscarDeProducto> resultados = buscarEnBaseDeDatos(nombre);

        // Añadir resultados a la lista
        listaProductos.addAll(resultados);

        // Actualizar la tabla
        tablaprueba.setItems(listaProductos);
    }

    //Método para mostrar un mensaje con el producto seleccionado
   public String mostrarProductoSeleccionado(BuscarDeProducto producto) {
    // Asigna el nombre del producto seleccionado al campo mensaje
    mensaje = producto.getNombre();
    System.out.println("Producto seleccionado: " + mensaje);
    
    // Actualiza el TextField 'buscProd' en Ingresar_FacturaController con el nombre seleccionado
    if (IngFac != null) { // Verifica que IngFac esté correctamente inicializado
        IngFac.buscProd.setText(mensaje);
    } else {
        System.out.println("Error: Ingresar_FacturaController no está inicializado.");
    }

    return mensaje;
}

    
  public ArrayList<BuscarDeProducto> buscarEnBaseDeDatos(String nombre) {
    Conexiónsql alta = new Conexiónsql();
    Connection conn = null;
    PreparedStatement psmt = null; 
    ResultSet rs = null;    
    ArrayList<BuscarDeProducto> productos = new ArrayList<>();
    
    // Obtener la conexión a la base de datos
    conn = alta.getConnection();   
    
    if (conn == null) {
        System.out.println("Error: No se pudo establecer la conexión a la base de datos.");
        return productos;  // Retorna la lista vacía si la conexión es nula
    }

    String sql = "SELECT Nombre, Descripcion FROM producto WHERE Nombre LIKE ?";
    
    try {
        // Inicializar el PreparedStatement con la consulta SQL
        psmt = conn.prepareStatement(sql);
        
        // Asignar el parámetro a la consulta SQL
        psmt.setString(1, "%" + nombre + "%");
        
        // Ejecutar la consulta
        rs = psmt.executeQuery();

        // Iterar sobre los resultados de la consulta
        while (rs.next()) {
            String nombreProducto = rs.getString("Nombre");
            String descripcionProducto = rs.getString("Descripcion");
            
            // Crear un objeto de tipo 'BuscarDeProducto' y añadirlo a la lista
            BuscarDeProducto producto = new BuscarDeProducto();
            producto.setNombre(nombreProducto);
            producto.setDescripcion(descripcionProducto);
            productos.add(producto);
        }

    } catch (SQLException e) {
        e.printStackTrace(); // Mostrar los detalles del error
    } finally {
        // Cerrar el ResultSet, PreparedStatement y la conexión para evitar fugas de recursos
        try {
            if (rs != null) rs.close();
            if (psmt != null) psmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    return productos;
}

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }
    
        
    public String getMensaje() {
        return mensaje;
    }
    
   
    @FXML
    private void AcepBot(ActionEvent event) throws SQLException {
        String prueba="";
        String pru;
        // Obtener el Stage (ventana) actual y cerrarla
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();        
                
       prueba=Modelo.FacturaModelo.TraerIDProd(mensaje);
        System.out.println(prueba);   
       IngFac.cargarDatos(mensaje);
        stage.close();
        
        
    }
}
