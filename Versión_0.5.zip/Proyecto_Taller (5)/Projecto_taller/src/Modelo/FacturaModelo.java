/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import com.mysql.cj.xdevapi.Statement;
import java.awt.HeadlessException;
import static java.lang.Integer.parseInt;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author 54255702
 */
public class FacturaModelo {
    
    //Metodo 9 de traer los productos de la base de datos y cargar el combobox
//Cargar Conbox con productos de la base de datos
public ArrayList<String> cargarDatosEnComboBox() {
    //establecemos la conexion
    Conexiónsql alta = new Conexiónsql();  // Instancia de la clase para obtener la conexión
    Connection conn = null;
    ArrayList<String> listaDeProductos = new ArrayList<>();

    try {
        // Inicializar la conexión a la base de datos
        conn = alta.getConnection();  // Asume que este método devuelve una conexión válida
        
        // Consulta SQL para los nombres de los productos
        String sql = "SELECT Nombre FROM producto"; 
        PreparedStatement psmt = conn.prepareStatement(sql);
        ResultSet rs = psmt.executeQuery();

        // Recorre los resultados y agrega los datos al ArrayList
        while (rs.next()) {
            listaDeProductos.add(rs.getString("Nombre"));
        }
        
        // Cerrar ResultSet y PreparedStatement después de usarlos
        rs.close();
        psmt.close();

    } catch (SQLException e) {
        e.printStackTrace();  // Manejo de errores
    } finally {
        try {
            // Cerrar la conexión si no es nula
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    return listaDeProductos; // Devolver los datos
}

//cargar combox de cliente
public ArrayList<String> cargarDatosEnComboBoxCliente() {
    //establecemos la conexion
    Conexiónsql alta = new Conexiónsql();  // Instancia de la clase para obtener la conexión
    Connection conn = null;
    ArrayList<String> listaDeClientes = new ArrayList<>();

    try {
        // Inicializar la conexión a la base de datos
        conn = alta.getConnection();  // Asume que este método devuelve una conexión válida
        
        // Consulta SQL para los nombres de los productos
        String sql = "SELECT Nombre FROM cliente"; 
         PreparedStatement psmt= conn.prepareStatement(sql);
        ResultSet rs = psmt.executeQuery();

        // Recorre los resultados y agrega los datos al ArrayList
        while (rs.next()) {
            listaDeClientes.add(rs.getString("Nombre"));
        }
        
        // Cerrar ResultSet y PreparedStatement después de usarlos
        rs.close();
        psmt.close();

    } catch (SQLException e) {
        e.printStackTrace();  // Manejo de errores
    } finally {
        try {
            // Cerrar la conexión si no es nula
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
      return listaDeClientes; // Devolver los datos
}

//cargar combox de cliente
public ArrayList<String> llenarComboBoxEmpleado() {
    //establecemos la conexion
    Conexiónsql alta = new Conexiónsql();  // Instancia de la clase para obtener la conexión
    Connection conn = null;
    ArrayList<String> listaDeEmpleado = new ArrayList<>();

    try {
        // Inicializar la conexión a la base de datos
        conn = alta.getConnection();  // Asume que este método devuelve una conexión válida
        
        // Consulta SQL para los nombres de los productos
        String sql = "SELECT Nombre FROM empleado"; 
         PreparedStatement psmt = conn.prepareStatement(sql);
        ResultSet rs = psmt.executeQuery();

        // Recorre los resultados y agrega los datos al ArrayList
        while (rs.next()) {
            listaDeEmpleado.add(rs.getString("Nombre"));
        }
        
        // Cerrar ResultSet y PreparedStatement después de usarlos
        rs.close();
        psmt.close();

    } catch (SQLException e) {
        e.printStackTrace();  // Manejo de errores
    } finally {
        try {
            // Cerrar la conexión si no es nula
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
      return listaDeEmpleado; // Devolver los datos
}

//cargar combox de sucursal
public ArrayList<String> llenarComboBoxSucursal() {
    //establecemos la conexion
    Conexiónsql alta = new Conexiónsql();  // Instancia de la clase para obtener la conexión
    Connection conn = null;
    ArrayList<String> listaDeSucursales = new ArrayList<>();

    try {
        // Inicializar la conexión a la base de datos
        conn = alta.getConnection();  // Asume que este método devuelve una conexión válida
        
        // Consulta SQL para los nombres de los productos
        String sql = "SELECT Nombre FROM sucursal"; 
         PreparedStatement psmt = conn.prepareStatement(sql);
        ResultSet rs = psmt.executeQuery();

        // Recorre los resultados y agrega los datos al ArrayList
        while (rs.next()) {
            listaDeSucursales.add(rs.getString("Nombre"));
        }
        
        // Cerrar ResultSet y PreparedStatement después de usarlos
        rs.close();
        psmt.close();

    } catch (SQLException e) {
        e.printStackTrace();  // Manejo de errores
    } finally {
        try {
            // Cerrar la conexión si no es nula
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
      return listaDeSucursales; // Devolver los datos
}
          
// Método modificado para aceptar ArrayList<Object>
public boolean CardarDetalleVentna(int id_venta,int idProducto, int cantidad, float precioUnitario, int subtotal, String nombreProducto) throws SQLException {
    
  Conexiónsql alta = new Conexiónsql();
         Connection conn = null;
        PreparedStatement psmt = null;
        conn = alta.getConnection();    
         ResultSet rs = null;

      String estad="en proceso";
      
       try {
        conn = alta.getConnection();
        if (conn == null || conn.isClosed()) {
            System.out.println("Error: La conexión a la base de datos no está activa.");
            return false;
        }
        
        
        // Consulta de inserción en detalle_venta
        String sqlInsert = "INSERT INTO detalle_venta(ID_Venta,ID_Producto,Cantidad,Precio_Unitario,Nom_Producto,Sub_Total,estado) VALUES (?,?,?,?,?,?,?)";
        psmt = conn.prepareStatement(sqlInsert);
        psmt.setInt(1, id_venta);  // Usamos el ID_Venta obtenido
        psmt.setInt(2, idProducto);
        psmt.setInt(3, cantidad);
        psmt.setFloat(4, precioUnitario);
        psmt.setString(5, nombreProducto);
        psmt.setInt(6, subtotal);
        psmt.setString(7,estad);
        
          int filasInsertadas = psmt.executeUpdate();
        if (filasInsertadas > 0) {
            System.out.println("Inserción exitosa: " + filasInsertadas + " filas insertadas.");
            conn.commit();
            return true;
        } else {
            System.out.println("No se insertaron filas.");
            conn.rollback();
            return false;
        }
        
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    } finally {
        try {
            if (rs != null) rs.close();
            if (psmt != null) psmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

public int TraerIDMaxDeFactura() throws SQLException{
     Conexiónsql alta = new Conexiónsql();
         Connection conn = null;
        PreparedStatement psmt = null;
        conn = alta.getConnection();    
         ResultSet rs = null;
         int increment=0;
         
    int e=0;
    // Obtén el último ID de la tabla
        String sqlMax = "SELECT MAX(id_factura) AS ultimo_id FROM ultimo_id_factura";
        psmt= conn.prepareStatement(sqlMax);
        rs = psmt.executeQuery();
        if (rs.next()) {
            increment = rs.getInt("ultimo_id") + 1; // Incrementa en caso de tener un ID existente
        }
        rs.close();
        psmt.close();

        // Inserta el nuevo ID incrementado en la tabla
        String sqlCargar = "INSERT INTO ultimo_id_factura(id_factura) VALUES(?)";
        psmt = conn.prepareStatement(sqlCargar);
        psmt.setInt(1, increment); // Asigna el valor incrementado de ID
        psmt.executeUpdate();
           System.out.println("el id es"+increment);
        
    
    return increment;
}

/*
    public boolean CardarDetalleVentna(String au,int cantidad, float ubitprecio, int total,String nomProd) throws SQLException{
    Conexiónsql alta = new Conexiónsql();
    Connection conn = null;
    PreparedStatement psmt = null;
    boolean resultado=true;
    ResultSet rs = null;
        conn = alta.getConnection();        
         int auu=0;
         auu=(Integer)parseInt(au);
             try {
                 //Hacemos la sentencia para hacer la sentencia sql
              String sql = "INSERT INTO detalle_venta(ID_Producto,Cantidad,Precio_Unitario,Nom_Producto, Sub_Total) VALUES (?,?,?,?,?)";
                        psmt = conn.prepareStatement(sql);
   // Establecer los valores en el PreparedStatement y los ordenamos para cargarlos en la base de datos
                         psmt.setInt(1, auu);
                         psmt.setInt(2,cantidad);  
                         psmt.setFloat(3, ubitprecio);  // Agregar el valor de id_prod
                         psmt.setString(4,nomProd);
                         psmt.setInt(5,total);
                        // psmt.executeUpdate();    
                        // Ejecutar la sentencia y obtener el número de filas afectadas
                        int filasAfectadas = psmt.executeUpdate();
                        //Si el numero de filas es mayor a 0 significa que se cargo los datos perfectamente
                        if(filasAfectadas>0){
                            //Suben los datos de manera normal 
                            conn.commit();
                        }else{
                         //si no se afecto ninguna linea pasa al rolback donde y buelve todo a la normalidad. 
                         conn.rollback();
                   }
                        // Cerrar el PreparedStatement
                        psmt.close();       
        } catch (HeadlessException | SQLException e) {
        JOptionPane.showMessageDialog(null, e + "No se Logro el producto");
        }
           if(conn!=null){
               conn.close();
           }
        return resultado;

    }
*/
        
    //otro proceso mas para la base de datos
public static String TraerIDProd(String prodd)throws SQLException{
    String idproducto="";
    Conexiónsql alta = new Conexiónsql();
    Connection conn = null;
    PreparedStatement psmt = null;
    ResultSet rs = null;
    conn = alta.getConnection();    
     try {
                 //Hacemos la sentencia para hacer la sentencia sql
        String sql = "Select ID_Producto FROM producto WHERE Nombre=?";
               psmt = conn.prepareStatement(sql);
               psmt.setString(1, prodd);
                  // Ejecutar la consulta y obtener el resultado
        rs = psmt.executeQuery();

        // Si se encuentra el producto, obtener el precio
        if (rs.next()) {
            idproducto = rs.getString("ID_Producto");
        } else {
            System.out.println("Producto no encontrado.");
        }
    } catch (SQLException e) {
        System.out.println("Error al obtener el precio: " + e.getMessage());
    } finally {
        // Cerrar los recursos
        try {
            if (rs != null) rs.close();
            if (psmt != null) psmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            System.out.println("Error al cerrar recursos: " + e.getMessage());
        }
    }
        return idproducto;    
}

        //Metodo 10 traer el precio del producto seleccionado en el combobox
//que dios nos ayude con esto
public static double TraerPrecio(String prod) throws SQLException {
    Conexiónsql alta = new Conexiónsql();
    Connection conn = null;
    PreparedStatement psmt = null;
    ResultSet rs = null;
    double preciooo = 0.0;

    try {
        // Obtener la conexión
        conn = alta.getConnection();
        
        // Preparar la consulta SQL
        String sql = "SELECT Precio FROM producto WHERE Nombre = ?";
        psmt = conn.prepareStatement(sql);
        psmt.setString(1, prod);  // Cambiado a setString para producto (String)

        // Ejecutar la consulta y obtener el resultado
        rs = psmt.executeQuery();

        // Si se encuentra el producto, obtener el precio
        if (rs.next()) {
            preciooo = rs.getDouble("Precio");
        } else {
            System.out.println("Producto no encontrado.");
        }
    } catch (SQLException e) {
        System.out.println("Error al obtener el precio: " + e.getMessage());
    } finally {
        // Cerrar los recursos
        try {
            if (rs != null) rs.close();
            if (psmt != null) psmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            System.out.println("Error al cerrar recursos: " + e.getMessage());
        }
    }
    return preciooo;  // Devolver el precio del producto
}


}
