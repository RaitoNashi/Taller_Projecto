/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author 54255702
 */
public class Sucursal {
    
    //Buscar ID sucursal por el nombre
 public static String BuscarIDSucu(String nom_Suc)throws SQLException{
    String idSucursal="";
    Conexiónsql alta = new Conexiónsql();
    Connection conn = null;
    PreparedStatement psmt = null;
    ResultSet rs = null;
    conn = alta.getConnection();    
     try {
                 //Hacemos la sentencia para hacer la sentencia sql
        String sql = "Select ID_Sucursal FROM sucursal WHERE Nombre=?";
               psmt = conn.prepareStatement(sql);
               psmt.setString(1, nom_Suc);
                  // Ejecutar la consulta y obtener el resultado
        rs = psmt.executeQuery();

        // Si se encuentra el producto, obtener el precio
        if (rs.next()) {
            idSucursal = rs.getString("ID_Sucursal");
        } else {
            System.out.println("Sucursal no encontrado.");
        }
    } catch (SQLException e) {
        System.out.println("Error al obtener el ID de la sucursal: " + e.getMessage());
    } finally {
        // Cerrar los recursos
        try {
            if (rs != null) rs.close();
            if (psmt != null) psmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            System.out.println("Error al cerrar recursos: " + e.getMessage());
        }
    }
        return idSucursal;    
}
    
    
    
    
    
}
