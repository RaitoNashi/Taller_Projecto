/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador.Cliente;

import Controlador.SceneManager;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;

/**
 * FXML Controller class
 *
 * @author raito
 */
public class Dar_de_alta_cliente_juridicoController implements Initializable {

    @FXML
    private TextArea tin;
    @FXML
    private TextArea nomb_empresa;
    @FXML
    private TextArea dir_empresa;
    @FXML
    private TextArea correo;
    @FXML
    private TextArea telefono;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    @FXML
    public void HandleVolverMenuCliente(ActionEvent event){
        SceneManager.getInstance().goBackMenuCliente();
    }    

    @FXML
    private void EnviarBT(ActionEvent event)throws SQLException{
            boolean resultado=true;
  
            String TI=tin.getText();
            String Nom_Emp=nomb_empresa.getText();
            String Dir_Emp=dir_empresa.getText();                       
            String Correo=correo.getText();
            String T=telefono.getText();
            int Telef=Integer.parseInt(T);
            int TIN=Integer.parseInt(TI);
            
            resultado=Modelo.Cliente1.AltaClienteJuridico(TIN,Nom_Emp,Dir_Emp,Correo,Telef);
        }
    
    }
    