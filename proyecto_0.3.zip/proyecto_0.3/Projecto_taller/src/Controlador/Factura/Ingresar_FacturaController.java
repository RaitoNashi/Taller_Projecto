package Controlador.Factura;

import Controlador.SceneManager;
import Modelo.Cliente1;
import Modelo.Conexiónsql;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import java.util.ArrayList;
import javafx.event.ActionEvent;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

/**
 * FXML Controller class
 *
 * @author raito
 */
public class Ingresar_FacturaController implements Initializable {
      
    @FXML
    public ComboBox<String> conxxx;  // ComboBox de JavaFX
    
    @FXML
    public ComboBox<String> ConClientes; //ComboBox de Clientes

    @FXML
    public ComboBox<String> conEmpleado; //ComboBox Empleado
    
    @FXML
    private TableView<?> tablewe;
      
    @FXML
    private TableColumn<?, ?> Produco;

    @FXML
    private TableColumn<?, ?> Cantid;

    @FXML
    private TableColumn<?, ?> UbitPrecio;

    @FXML
    private TableColumn<?, ?> subTotal;
    
    @FXML
    private TextField IDVenta;
    
    @FXML
    private TextField IDProducto;
    
    @FXML
    private TextField CantProducto;
    
    @FXML
    private TextField Cedula;
 
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO     
         Conexiónsql alta = new Conexiónsql();
         Connection conn = null;
        llenarComboBoxConDatos();
        llenarComboBoxCliente();
        llenarComboBoxEmpleado();
    }  
    
    public void MostrarMenuPrincipal(){
        SceneManager.getInstance().goBack();
    }
    
    //Este PopUp está iniciliazado en el controlador SceneManager
    public void MostrarPopUp(){
        SceneManager.getInstance().MostrarPopUp();
        limpiarCampos();
    }
    
    private void limpiarCampos(){
        IDVenta.clear();
        IDProducto.clear();
        CantProducto.clear();
        Cedula.clear();
        
    }
    
    
     private void llenarComboBoxConDatos() {
           // Crear una instancia de la clase que obtiene los datos de la BD
           Modelo.Cliente1 cli1 = new Modelo.Cliente1();
        // Llamar al método que obtiene los datos
        ArrayList<String> listaDeProductos = cli1.cargarDatosEnComboBox();

        // Limpiar el ComboBox antes de agregar nuevos datos
        conxxx.getItems().clear();

        // Llenar el ComboBox con los datos obtenidos
        conxxx.getItems().addAll(listaDeProductos);
    }
     
     private void llenarComboBoxCliente() {
           // Crear una instancia de la clase que obtiene los datos de la BD
           Modelo.Cliente1 cli1 = new Modelo.Cliente1();
        // Llamar al método que obtiene los datos
        ArrayList<String> listaDeClientes = cli1.cargarDatosEnComboBoxCliente();
        // Limpiar el ComboBox antes de agregar nuevos datos
        ConClientes.getItems().clear();
         // Llenar el ComboBox con los datos obtenidos
         ConClientes.getItems().addAll(listaDeClientes);
    }
      
      private void llenarComboBoxEmpleado() {
           // Crear una instancia de la clase que obtiene los datos de la BD
           Modelo.Cliente1 cli1 = new Modelo.Cliente1();
        // Llamar al método que obtiene los datos
        ArrayList<String> listaDeEmpleado = cli1.llenarComboBoxEmpleado();
        // Limpiar el ComboBox antes de agregar nuevos datos
        conEmpleado.getItems().clear();
        // Llenar el ComboBox con los datos obtenidos
        conEmpleado.getItems().addAll(listaDeEmpleado);
    }
      
    @FXML
    private void agregar(ActionEvent event) throws SQLException {
       String prod = conxxx.getSelectionModel().getSelectedItem();
        double fprecio;
        if (prod != null) {
            //System.out.println(prod);
            fprecio=Modelo.Cliente1.TraerPrecio(prod);
            System.out.println(fprecio);
        } else {
            System.out.println("No item selected");
        }
    }
   
}