/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador.Inventario;

import Controlador.SceneManager;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableView;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author raito
 */
public class InventarioController implements Initializable {
    
    @FXML
    private TableView<?> tableView;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

    }    
    public void MostrarMenuPrincipal(){
        SceneManager.getInstance().goBack();
    }
}
