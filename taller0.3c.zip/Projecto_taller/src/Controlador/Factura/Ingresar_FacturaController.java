package Controlador.Factura;

import Controlador.SceneManager;
import Modelo.Cliente1;
import Modelo.Conexiónsql;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import java.util.ArrayList;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import java.time.LocalDate;
//nuevo
import javafx.scene.control.DatePicker;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javafx.scene.control.cell.PropertyValueFactory;
import java.lang.Math;
import Controlador.Factura.cargarTabla;

/**
 * FXML Controller class
 *
 * @author raito
 */
public class Ingresar_FacturaController implements Initializable {
   public int auxsubtotal=0;
    private int cantidadprod;
    private double unitpr;
    private double subtoto;
    private int auxiliar;
    public String au;
    private  boolean cargo=true;

   
   // boolean cargo= Modelo.Cliente1.CargarDetalleVentna(cantidadprod, cantidadprod, unitpr);
    @FXML
    public ComboBox<String> conxxx;  // ComboBox de JavaFX
    
    @FXML
    public ComboBox<String> ConClientes; //ComboBox de Clientes

    @FXML
    public ComboBox<String> conEmpleado; //ComboBox Empleado
    
    @FXML
    public TableView<cargarTabla> tableView; // Renombrado para mayor claridad
    @FXML
    public TableColumn<cargarTabla, String> Produco;
    @FXML
    public TableColumn<cargarTabla, Integer> Cantid;
    @FXML
    public TableColumn<cargarTabla, Double> UbitPrecio; // Cambiado a Double
    @FXML
    public TableColumn<cargarTabla, Double> subTotal; // Cambiado a Double

    @FXML
    private TextField IDVenta;
    @FXML
    private TextField IDProducto;
    @FXML
    private TextField CantProducto;
    @FXML
    private TextField Cedula;
    @FXML
    private DatePicker fecha;
    @FXML
    private Button agregarr;
    @FXML
    private TextField TOTAL;
    
    private ArrayList<cargarTabla>ListaDatos=new ArrayList<>();
      // ArrayList listaDatos = new ArrayList<>(); 
    @Override
    public void initialize(URL url, ResourceBundle rb){
       // cargarDatos(); 
        // TODO     
        Conexiónsql alta = new Conexiónsql();
        Connection conn = null;
        llenarComboBoxConDatos();
        llenarComboBoxCliente();
        llenarComboBoxEmpleado();
        // Inicializa las columnas
        Produco.setCellValueFactory(new PropertyValueFactory<>("producto"));
        Cantid.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
        UbitPrecio.setCellValueFactory(new PropertyValueFactory<>("unitprecio"));
        subTotal.setCellValueFactory(new PropertyValueFactory<>("SubTotal"));
  // Inicializa las variables
    cantidadprod = 0;
    unitpr = 0.0;
   
}  
    
    public void MostrarMenuPrincipal(){ 
        SceneManager.getInstance().goBack();
    }
    
    //Este PopUp está iniciliazado en el controlador SceneManager
    public void MostrarPopUp() throws SQLException{
      Modelo.Cliente1 cli1 = new Modelo.Cliente1();
        cargo = cli1.CardarDetalleVentna(cantidadprod, cantidadprod, (float) unitpr);
        if(cargo!=true){
            System.out.println(cargo);
        }else{
            System.out.println("error");
        }
        SceneManager.getInstance().MostrarPopUp();
        limpiarCampos();
    }
   
    private void limpiarCampos(){
        IDVenta.clear();
        IDProducto.clear();
        CantProducto.clear();
        Cedula.clear();
        
    }
    
    //LLENAR LA TABLA
    @FXML
    public void cargarDatos() throws SQLException {
    // Limpiar la lista antes de cargar nuevos datos
    ListaDatos.clear();
    // Verificar si hay un producto seleccionado en el ComboBox
    String prodddd = conxxx.getSelectionModel().getSelectedItem();
    if (prodddd == null) {
        System.out.println("No se ha seleccionado ningún producto.");
        return; // Salir del método si no hay selección
    }
    // Obtener la cantidad del TextField y convertirla a int
    try {
        cantidadprod = Integer.parseInt(CantProducto.getText());
    } catch (NumberFormatException e) {
        System.out.println("La cantidad ingresada no es un número válido.");
        return; // Salir del método si la conversión falla
    }
    try {
    unitpr = Modelo.Cliente1.TraerPrecio(prodddd);
    } catch (SQLException e) {
    System.out.println("Error al obtener el precio: " + e.getMessage());
    return; // Salir del método si hay un error
}
    subtoto=unitpr*cantidadprod;
    // Simular la carga de datos locales
    ListaDatos.add(new cargarTabla(prodddd, cantidadprod,unitpr, subtoto));

   // Actualizar la tabla
    //tableView.getItems().clear(); // Limpiar los elementos actuales de la tabla
    tableView.getItems().addAll(ListaDatos); // Agregar todos los elementos de la lista
    int u=(int) Math.round(subtoto);
    auxsubtotal=u+auxsubtotal;
    TOTAL.setText(String.valueOf(auxsubtotal));
    
    au = Modelo.Cliente1.TraerIDProd(prodddd);
if (au != null) {
    auxiliar = Integer.parseInt(au);
} else {
    System.out.println("No se pudo obtener el ID del producto.");
    return; // Salir del método si no se encuentra el ID
}
}
    
    //TODOS LOS COMBOBOX
     private void llenarComboBoxConDatos() {
           // Crear una instancia de la clase que obtiene los datos de la BD
           Modelo.Cliente1 cli1 = new Modelo.Cliente1();
        // Llamar al método que obtiene los datos
        ArrayList<String> listaDeProductos = cli1.cargarDatosEnComboBox();
        // Limpiar el ComboBox antes de agregar nuevos datos
        conxxx.getItems().clear();
        // Llenar el ComboBox con los datos obtenidos
        conxxx.getItems().addAll(listaDeProductos);
    }
     
     
     private void llenarComboBoxCliente() {
           // Crear una instancia de la clase que obtiene los datos de la BD
           Modelo.Cliente1 cli1 = new Modelo.Cliente1();
        // Llamar al método que obtiene los datos
        ArrayList<String> listaDeClientes = cli1.cargarDatosEnComboBoxCliente();
        // Limpiar el ComboBox antes de agregar nuevos datos
        ConClientes.getItems().clear();
         // Llenar el ComboBox con los datos obtenidos
         ConClientes.getItems().addAll(listaDeClientes);
    }
      
      private void llenarComboBoxEmpleado() {
           // Crear una instancia de la clase que obtiene los datos de la BD
           Modelo.Cliente1 cli1 = new Modelo.Cliente1();
        // Llamar al método que obtiene los datos
        ArrayList<String> listaDeEmpleado = cli1.llenarComboBoxEmpleado();
        // Limpiar el ComboBox antes de agregar nuevos datos
        conEmpleado.getItems().clear();
        // Llenar el ComboBox con los datos obtenidos
        conEmpleado.getItems().addAll(listaDeEmpleado);
    }
      
    @FXML
    private void agregar(ActionEvent event) throws SQLException {
       String prod = conxxx.getSelectionModel().getSelectedItem();
        double fprecio;
        if (prod != null) {
            //System.out.println(prod);
            fprecio=Modelo.Cliente1.TraerPrecio(prod);
            System.out.println(fprecio);
        } else {
            System.out.println("No item selected");
        }
        cargarDatos();     
    }
   
}