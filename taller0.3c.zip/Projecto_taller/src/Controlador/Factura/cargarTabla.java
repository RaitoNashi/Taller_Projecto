/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador.Factura;

/**
 *
 * @author 54255702
 */
public class cargarTabla {
    private String producto;
    private int cantidad;
    private double unitprecio; 
    private double SubTotal;
   
    public cargarTabla(String producto, int cantidad, double unitprecio,double SubTotal) {
        this.producto = producto;
        this.cantidad = cantidad;
        this.unitprecio = unitprecio;
        this.SubTotal= SubTotal;
      
    }

    public double getSubTotal() {
        return SubTotal;
    }

    public void setSubTotal(double SubTotal) {
        this.SubTotal = SubTotal;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }
    
    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getUnitprecio() {
        return unitprecio;
    }

    public void setUnitprecio(double unitprecio) {
        this.unitprecio = unitprecio;
    }

    

  
  
    
}
