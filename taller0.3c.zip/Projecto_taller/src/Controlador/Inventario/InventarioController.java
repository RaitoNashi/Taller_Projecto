/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador.Inventario;

import Controlador.SceneManager;
import Modelo.Conexiónsql;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author raito
 */
public class InventarioController implements Initializable {
    
     @FXML
    private TableView<producto> tableView;

    @FXML
    private TableColumn<?, ?> colID;

    @FXML
    private TableColumn<producto, String> ColNom;

    @FXML
    private TableColumn<?, ?> ColDesc;

    @FXML
    private TableColumn<producto, Float> ColPrecio;

    @FXML
    private TableColumn<producto, Integer>  ColStock;
            
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    // Inicializa las columnas
    ColNom.setCellValueFactory(new PropertyValueFactory<>("nombre"));
    ColStock.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
    ColPrecio.setCellValueFactory(new PropertyValueFactory<>("precio"));
     // En algún lugar de tu código, como en un evento de botón
        InventarioController dader = new InventarioController();
        dader.cargarProductos(this); // 'this' se refiere a la instancia del controlador

    }    
    public void MostrarMenuPrincipal(){
        SceneManager.getInstance().goBack();
    }
    
    public void cargarDatos(ArrayList<producto> listaProductos) {
    tableView.getItems().clear(); // Limpiar datos anteriores
    tableView.getItems().addAll(listaProductos); // Agregar nuevos datos
    
}
     public void cargarProductos(InventarioController controller) {
        ArrayList<producto> productos = new ArrayList<>();
       //conexión a la base de datos
         Conexiónsql alta = new Conexiónsql();
         Connection conn = null;
         PreparedStatement psmt = null;
        ResultSet rs = null;

    try {
        // Obtener la conexión
        conn = alta.getConnection();
        
         // Preparar la consulta SQL
        String sql = "SELECT * FROM producto";
        psmt = conn.prepareStatement(sql);
         // Ejecutar la consulta y obtener el resultado
        rs = psmt.executeQuery();
        
            // Recorrer los resultados y crear objetos Producto
            while (rs.next()) {
                String nombre = rs.getString("Nombre");
                if(nombre.toString()!=null){
                    System.out.println("Vamos correcto");
                }
                float precio = rs.getFloat("Precio");
                if (!Float.isNaN(precio)) {
                // precio es un float válido
                    System.out.println("siga bien");
}
                
                int cantidad = rs.getInt("Stock");             
                if (!Double.isNaN(cantidad)) {
                // cantidad es un double válido
                    System.out.println("exitos");
               }
                producto producto = new producto(nombre, precio,cantidad);
                productos.add(producto);
            }
    }catch (SQLException e) {
            System.err.println("Error al conectar a la base de datos: " + e.getMessage());
        }

        // Llamar al método del controlador para llenar el TableView
         controller.cargarDatos(productos);
    /*    
// Aquí puedes llenar la lista de productos desde una base de datos o cualquier otra fuente
        productos.add(new producto("Producto 1", 10, 5.99));
        productos.add(new producto("Producto 2", 20, 15.49));
        
        // Llamar al método del controlador para llenar el TableView
        controller.cargarDatos(productos);
    }*/}
}
