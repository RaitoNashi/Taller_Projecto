/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador.Compra_Controller;

import Controlador.SceneManager;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author raito
 */
public class Ingresar_CompraController implements Initializable {
    
    @FXML
    private TextField IDVenta;
    
    @FXML
    private TextField IDProducto;
    
    @FXML
    private TextField CantProducto;
    
    @FXML
    private TextField Cedula;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    
    public void MostrarMenuPrincipal(){
        SceneManager.getInstance().goBack();
    }
    
    public void MostrarPopUp(){
        SceneManager.getInstance().MostrarPopUp();
        limpiarCampos();
    }
    
    private void limpiarCampos(){
        IDVenta.clear();
        IDProducto.clear();
        CantProducto.clear();
        Cedula.clear();
        
    }
}
    