package Controlador.Inventario;


import Controlador.SceneManager;
import Modelo.Conexiónsql;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;

import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.beans.property.SimpleObjectProperty;

public class InventarioController implements Initializable {

    @FXML
    private TableView<ArrayList<Object>> tableView;

    @FXML
    private TableColumn<ArrayList<Object>, Integer> colID;
    @FXML
    private TableColumn<ArrayList<Object>, String> ColNom;
    @FXML
    private TableColumn<ArrayList<Object>, String> ColDesc;
    @FXML
    private TableColumn<ArrayList<Object>, Float> ColPrecio;
    @FXML
    private TableColumn<ArrayList<Object>, Integer> ColStock;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        // Configuración de las columnas
        colID.setCellValueFactory(cellData -> new SimpleObjectProperty<>((Integer) cellData.getValue().get(0)));
        ColNom.setCellValueFactory(cellData -> new SimpleObjectProperty<>((String) cellData.getValue().get(1)));
        ColDesc.setCellValueFactory(cellData -> new SimpleObjectProperty<>((String) cellData.getValue().get(2)));
        ColPrecio.setCellValueFactory(cellData -> new SimpleObjectProperty<>((Float) cellData.getValue().get(3)));
        ColStock.setCellValueFactory(cellData -> new SimpleObjectProperty<>((Integer) cellData.getValue().get(4)));

           // Configura el cellFactory para la columna ColPrecio
// Configura el cellFactory para la columna ColPrecio
ColPrecio.setCellFactory(column -> new TableCell<ArrayList<Object>, Float>() {
    @Override
    protected void updateItem(Float item, boolean empty) {
        super.updateItem(item, empty);
        setText(empty || item == null ? null : String.format("%.2f", item));
        setStyle("-fx-alignment: CENTER-RIGHT;");
    }
});


// Configura el cellFactory para la columna ColStock
    ColStock.setCellFactory(column -> new TableCell<ArrayList<Object>, Integer>() {
    @Override
    protected void updateItem(Integer item, boolean empty) {
        super.updateItem(item, empty);
        setText(empty || item == null ? null : String.valueOf(item));
        setStyle("-fx-alignment: CENTER-RIGHT;");
    }
});

        cargarProductos();
    }

    private Callback<TableColumn<ArrayList<Object>, Object>, TableCell<ArrayList<Object>, Object>> createFormattedCellFactory(String format) {
        return column -> new TableCell<>() {
            @Override
            protected void updateItem(Object item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : String.format(format, item));
                setStyle("-fx-alignment: CENTER-RIGHT;");
            }
        };
    }

   public void cargarProductos() {
    ArrayList<ArrayList<Object>> productos = new ArrayList<>();
    
    // Conexión a la base de datos
    Conexiónsql alta = new Conexiónsql();
    Connection conn = null;
    PreparedStatement psmt = null;
    ResultSet rs = null;

    try {
        // Obtener la conexión
        conn = alta.getConnection();
        
        if (conn == null) {
            System.err.println("Error: No se pudo establecer la conexión con la base de datos.");
            return;
        }

        // Preparar la consulta SQL
        String sql = "SELECT * FROM producto";
        psmt = conn.prepareStatement(sql);
        
        // Ejecutar la consulta y obtener el resultado
        rs = psmt.executeQuery();

        if (rs == null) {
            System.err.println("Error: No se recibió ningún resultado de la consulta SQL.");
            return;
        }

        // Procesar el resultado de la consulta
        while (rs.next()) {
            ArrayList<Object> fila = new ArrayList<>();
            fila.add(rs.getInt("ID_Producto"));  // ID
            fila.add(rs.getString("Nombre"));     // Nombre
            fila.add(rs.getString("Descripcion")); // Descripción
            fila.add(rs.getFloat("Precio"));      // Precio
            fila.add(rs.getInt("Stock"));         // Stock
            
            productos.add(fila);
        }
        
    } catch (SQLException e) {
        System.err.println("Error al conectar a la base de datos: " + e.getMessage());
    } finally {
        // Cerrar recursos
        try {
            if (rs != null) rs.close();
            if (psmt != null) psmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            System.err.println("Error al cerrar recursos: " + e.getMessage());
        }
    }

    cargarDatos(productos);
}

    public void cargarDatos(ArrayList<ArrayList<Object>> productos) {
        tableView.getItems().clear();
        tableView.getItems().addAll(productos);
    }

    public void MostrarMenuPrincipal(){
        SceneManager.getInstance().goBack();
    }
}


/*
 * FXML Controller class
 *
 * @author raito
 
public class InventarioController implements Initializable {
    
     @FXML
    private TableView<producto> tableView;

    @FXML
    private TableColumn<producto, Integer> colID;

    @FXML
    private TableColumn<producto, String> ColNom;

    @FXML
    private TableColumn<producto, String> ColDesc;

    @FXML
    private TableColumn<producto, Float> ColPrecio;

    @FXML
    private TableColumn<producto, Integer>  ColStock;
            
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    // Inicializa las columnas
    ColNom.setCellValueFactory(new PropertyValueFactory<>("nombre"));
    ColStock.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
    ColPrecio.setCellValueFactory(new PropertyValueFactory<>("precio"));
    colID.setCellValueFactory(new PropertyValueFactory<>("id"));
    ColStock.setCellValueFactory(new PropertyValueFactory("stok"));
    ColDesc.setCellValueFactory(new PropertyValueFactory<>("desc"));  // Descripción del producto
    // Configura el cellFactory para la columna ColPrecio
// Configura el cellFactory para la columna ColPrecio
ColPrecio.setCellFactory(column -> new TableCell<producto, Float>() {
    @Override
    protected void updateItem(Float item, boolean empty) {
        super.updateItem(item, empty);
        setText(empty || item == null ? null : String.format("%.2f", item));
        setStyle("-fx-alignment: CENTER-RIGHT;");
    }
});

// Configura el cellFactory para la columna ColStock
ColStock.setCellFactory(column -> new TableCell<producto, Integer>() {
    @Override
    protected void updateItem(Integer item, boolean empty) {
        super.updateItem(item, empty);
        setText(empty || item == null ? null : String.valueOf(item));
        setStyle("-fx-alignment: CENTER-RIGHT;");
    }
});

     // En algún lugar de tu código, como en un evento de botón
        InventarioController dader = new InventarioController();
        dader.cargarProductos(this); // 'this' se refiere a la instancia del controlador

    }    
    public void MostrarMenuPrincipal(){
        SceneManager.getInstance().goBack();
    }
    
    public void cargarDatos(ArrayList<producto> listaProductos) {
    tableView.getItems().clear(); // Limpiar datos anteriores
    tableView.getItems().addAll(listaProductos); // Agregar nuevos datos
    
}
     public void cargarProductos(InventarioController controller) {
        ArrayList<producto> productos = new ArrayList<>();
       //conexión a la base de datos
         Conexiónsql alta = new Conexiónsql();
         Connection conn = null;
         PreparedStatement psmt = null;
        ResultSet rs = null;

    try {
        // Obtener la conexión
        conn = alta.getConnection();
        
         // Preparar la consulta SQL
        String sql = "SELECT * FROM producto";
        psmt = conn.prepareStatement(sql);
         // Ejecutar la consulta y obtener el resultado
        rs = psmt.executeQuery();
        
            // Recorrer los resultados y crear objetos Producto
            while (rs.next()) {
                String nombre = rs.getString("Nombre");
                float precio = rs.getFloat("Precio");
                int id = rs.getInt("ID_Producto");  // Asegúrate de que esta columna existe en tu base de datos
                String desc = rs.getString("Descripcion");  // Obtener la descripción del producto
                int cantidad = rs.getInt("Stock");             
                producto producto = new producto(nombre,cantidad,precio,id,desc,cantidad);
                productos.add(producto);
            }
    }catch (SQLException e) {
            System.err.println("Error al conectar a la base de datos: " + e.getMessage());
        }

        // Llamar al método del controlador para llenar el TableView
         controller.cargarDatos(productos);

     }
}
*/