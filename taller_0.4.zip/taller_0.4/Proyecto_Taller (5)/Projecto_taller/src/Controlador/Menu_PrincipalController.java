/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador;

import Controlador.Inventario.InventarioController;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;


/**
 * FXML Controller class
 *
 * @author raito
 */
public class Menu_PrincipalController implements Initializable {
    @FXML
    private AnchorPane rootPane;
    private Stage stage; 

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    @FXML
    public void handleCliente(ActionEvent event) {
        SceneManager.getInstance().changeScene("/Vista/Cliente/Cliente_Menu.fxml");
    }
    
    @FXML
    public void handleIngresarCompra(ActionEvent event){
        SceneManager.getInstance().changeScene("/Vista/Facturación/Factura_Ingresar.fxml");
    }
    
    @FXML
    public void handleInventario(ActionEvent event) throws IOException{
        
        SceneManager.getInstance().changeScene("/Vista/Inventario.fxml");
    }       
      
    @FXML
    public void handleEnviodePaquetes(ActionEvent event) throws IOException{
        
        SceneManager.getInstance().changeScene("/Vista/Paquete_Envio.fxml");
    }
    
    @FXML
    public void handleRastreodePaquete(ActionEvent event) throws IOException{
        
        SceneManager.getInstance().changeScene("/Vista/Paquete_Rastreo.fxml");
        
    }
    
    @FXML
    public void handleListaEmpleados(ActionEvent event) throws IOException{
        
        SceneManager.getInstance().changeScene("/Vista/Empleado/EmpleadoMenu.fxml");
    }
    
    @FXML
    public void handleHistorial(ActionEvent event) throws IOException{
        
        SceneManager.getInstance().changeScene("/Vista/Historial.fxml");
    }
    
}
