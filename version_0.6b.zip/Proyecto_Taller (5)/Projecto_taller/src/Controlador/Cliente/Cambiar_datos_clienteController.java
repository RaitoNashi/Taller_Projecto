/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador.Cliente;

import Controlador.SceneManager;
import Modelo.Cliente1;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author raito
 */
public class Cambiar_datos_clienteController implements Initializable{
    // Variables para almacenar los valores iniciales
      public String nombreInicial;
      public String apellidoInicial;
      public String direccionInicial;
      public String telefonoInicial;
      public String cedulaInicial;
      
     @FXML
    AnchorPane rootPane;
    
    @FXML
    public TextField ModNom;

    @FXML
    public TextField ModApe;

    @FXML
    public TextField ModDirec;

    @FXML
    public TextField FilCedu;

    @FXML
    public TextField ModTelef;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         // Al cargar la pantalla, guardamos los valores iniciales
    nombreInicial = ModNom.getText();
    apellidoInicial = ModApe.getText();
    direccionInicial = ModDirec.getText();
    telefonoInicial = ModTelef.getText();
    cedulaInicial = FilCedu.getText();
       
    
     rootPane.getStylesheets().add(getClass().getResource("/Estilos/Estilos.css").toExternalForm());
    
    }    
    
      @FXML
    void modificar(ActionEvent event) {
          Modelo.Cliente1 cc = new Cliente1();
            boolean resultado=true;
            
             // Verificar cuáles TextFields han cambiado
    boolean nombreModificado = !ModNom.getText().equals(nombreInicial);
    boolean apellidoModificado = !ModApe.getText().equals(apellidoInicial);
    boolean direccionModificada = !ModDirec.getText().equals(direccionInicial);
    boolean telefonoModificado = !ModTelef.getText().equals(telefonoInicial);
    boolean cedulaModificado = !FilCedu.getText().equals(cedulaInicial); 
             
             String cedula="";
             String apellido="";
             String direc="";
             String nom="";
             int telef =0;
            
                      
        if(cedulaModificado){
            cedula=FilCedu.getText();
        }
        if(apellidoModificado){
            apellido=ModApe.getText();
         
        }
          if(nombreModificado){
            nom=ModNom.getText();
        }
            if(telefonoModificado){
          String t=ModTelef.getText();
            telef=Integer.parseInt(t);
        }
           if(direccionModificada){
            direc=ModDirec.getText();
        }
      
           // hasta aca todo joya     System.out.println("bine cedula"+cedula+"nombre nuevo"+nom);
        resultado=cc.CambiarDatosCliente( cedula, nom, apellido, direc,telef);
        
    }
    
        public void HandleVolverMenuCliente(ActionEvent event){
        SceneManager.getInstance().goBackMenuCliente();
    }
}
