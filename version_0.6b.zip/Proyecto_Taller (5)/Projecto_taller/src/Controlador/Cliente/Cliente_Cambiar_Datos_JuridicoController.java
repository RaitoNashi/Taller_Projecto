/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador.Cliente;

import Controlador.SceneManager;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author raito
 */
public class Cliente_Cambiar_Datos_JuridicoController implements Initializable {
  
        // Variables para almacenar los valores iniciales
      public int TINN;
      public String NomEmpresa;
      public String DirEmpresa;
      public String CorEmpresa;
      public int TelEmpresa;
      
    @FXML
    AnchorPane rootPane;
      
    @FXML
    private TextField DirEmp;

    @FXML
    private TextField NomEmp;

    @FXML
    private TextField TellEmp;

    @FXML
    private TextField CorEmp;

    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
      rootPane.getStylesheets().add(getClass().getResource("/Estilos/Estilos.css").toExternalForm());
    
   
    }    
    
    public void HandleVolverMenuCliente(ActionEvent event){
        SceneManager.getInstance().goBackMenuCliente();
    }
    
    @FXML
    void Enviarbt(ActionEvent event) {

    }
    
}
