/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador.Cliente;

import Controlador.SceneManager;
import Modelo.Cliente1;
import Modelo.Conexiónsql;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.layout.AnchorPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 * FXML Controller class
 *
 * @author raito
 */
public class Dar_de_alta_clienteController implements Initializable {
    
    String TipDocSel="";
    
    @FXML
    private TextArea ClienteNombre;
    
    @FXML
    private TextArea ClienteApellido;
    
    @FXML
    private TextArea ClienteCedula;
    
    @FXML
    private TextArea ClienteDireccion;
    
    @FXML
    private TextArea ClienteTelefono;
    
    @FXML
    private ComboBox<String> tipoDOC;
    
    @FXML
    AnchorPane rootPane;
    
    public void initialize(URL url, ResourceBundle rb) {
    rootPane.getStylesheets().add(getClass().getResource("/Estilos/Estilos.css").toExternalForm());
    tipoDOC.getItems().addAll("Cedula","Pasaporte","DNI","Cedula Extranjera","Licencia de Conducir");
   
    // Listener para actualizar el valor seleccionado en tiempo real
        tipoDOC.valueProperty().addListener((observable, oldValue, newValue) -> { 
            TipDocSel=newValue;
            System.out.println(TipDocSel);
     });
        
    }    
    
    
    public void HandleVolverMenuCliente(ActionEvent event){
        SceneManager.getInstance().goBackMenuCliente();
    }
    
    
    @FXML
    public void HandleEnviar(ActionEvent event)throws SQLException{
            Modelo.Cliente1 ClienteEnvio = new Cliente1();
            boolean resultado=true;
            int telefono=0;
            // Verificar que los datos no esten vacios
            String nombre=ClienteNombre.getText();
            if(nombre.isEmpty()){
               // Crear y agregar un JLabel al panel
             JOptionPane.showMessageDialog(null, "nombre invalido");
                return;
            }
            String direccion=ClienteDireccion.getText();
            if(direccion.isEmpty()){
                // Crear y agregar un JLabel al panel
            JOptionPane.showMessageDialog(null, "dirección invalida");
            return;
            }
                            
            String apellido=ClienteApellido.getText();
            if(apellido.isEmpty()){
                // Crear y agregar un JLabel al panel
            JOptionPane.showMessageDialog(null, "campo invalido");
            return;
            }
            String cedula=ClienteCedula.getText();
            if(cedula.isEmpty()){
                // Crear y agregar un JLabel al panel
            JOptionPane.showMessageDialog(null, "cedula invalida o no cuenta con los caracteres suficientes");
            }
            String t=ClienteTelefono.getText();     
            
            if(t.length()<9){
                // Crear y agregar un JLabel al panel
             JOptionPane.showMessageDialog(null, "telefono invalido o no cuenta con los caracteres suficientes");
            return;
            }else{
                telefono=Integer.parseInt(t);
            }
        System.out.println(TipDocSel);
            resultado=Modelo.Cliente1.Altacliente(nombre, direccion, telefono, apellido, cedula,TipDocSel);
        
    }
    
    
}
