/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador.Cliente;

import Controlador.SceneManager;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author raito
 */
public class Dar_de_alta_cliente_juridicoController implements Initializable {

    @FXML
    private TextArea tin;
    @FXML
    private TextArea nomb_empresa;
    @FXML
    private TextArea dir_empresa;
    @FXML
    private TextArea correo;
    @FXML
    private TextArea telefono;

     @FXML
    AnchorPane rootPane;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    rootPane.getStylesheets().add(getClass().getResource("/Estilos/Estilos.css").toExternalForm());
  
    }    
    
    @FXML
    public void HandleVolverMenuCliente(ActionEvent event){
        SceneManager.getInstance().goBackMenuCliente();
    }    

    @FXML
    private void EnviarBT(ActionEvent event)throws SQLException{
            boolean resultado=true,ValiCorreo=false;
            int TIN=0;
            String TI=tin.getText();
            if(TI==null || TI.isEmpty()){
                System.out.println("campo tin vacio");
            }else{
                 TIN=Integer.parseInt(TI);
            }           
            String Nom_Emp=nomb_empresa.getText();
            if(Nom_Emp==null || Nom_Emp.isEmpty()){
                System.out.println("nombre de empresa vacio: ");
                return; 
            }
            String Dir_Emp=dir_empresa.getText();                       
            if(Dir_Emp==null || Dir_Emp.isEmpty()){
                System.out.println("Dirreccion de la empresa vacio");
                return;
            }
            String Correo=correo.getText();
            if(Correo==null || Correo.isEmpty()){
                System.out.println("correo vacio");
                return;
            }else{
                ValiCorreo=VeriCorreo(Correo);
               if(ValiCorreo){
                   System.out.println("correo correcto");
            }else{
                   return;
               }
            }
            String T=telefono.getText();
            int Telef=Integer.parseInt(T);
            
              if(tieneNueveDigitos(Telef)) {
            System.out.println("El número tiene 9 dígitos.");
            
        } else {
            System.out.println("El número no tiene 9 dígitos.");
            return;
        }
           
     
            resultado=Modelo.Cliente1.AltaClienteJuridico(TIN,Nom_Emp,Dir_Emp,Correo,Telef);
        }
    
    
        public boolean VeriCorreo(String correo){
            int con=0,con2=0,con3=0;
            boolean verdom=false,vernom=false,verdomi=false;
            
            for(int y=0;y<correo.length();y++){
                char caracte=correo.charAt(y);
                if(caracte=='@'){
                    con3=y;
                }
            }
            String usuario=correo.substring(0,con3);
            if(usuario!=null){
                vernom=true;
            }else{
                System.out.println("Verificar nombre de usuario de su correo");
                vernom=false;
                return vernom;
            }
            System.out.println("usuario: "+usuario);
            for(int x=0;x<correo.length();x++){
                char caracter=correo.charAt(x);
                if(caracter=='@'){
                    con=x+1;
                }
                if(caracter=='.'){
                    con2=x;
                }
            }
            String dom=correo.substring(con,con2);
             if(dom.equals("gmail") || dom.equals("outlook") || dom.equals("yahoo") || dom.equals("hotmail")){
                 System.out.println(dom);
                 verdom=true;
                
             }else{
                 System.out.println(dom);
                 System.out.println("Dominio de su correo no valido, verifique");
                 verdom=false;
                 return verdom;
             }
             String domfin=correo.substring(con2+1,correo.length());
            if(domfin.equals("com") || domfin.equals("org") || domfin.equals("net") || domfin.equals("edu") || domfin.equals("gov")){
                System.out.println(domfin);
                verdomi=true;
            } else{
                System.out.println(domfin);
                System.out.println("Domino incorrecto pruebe con (com,org,net,edu,gov)");
                verdomi=false;
                return verdomi;
            }
          
            return true;
        }
    
    public static boolean tieneNueveDigitos(int numero) {
        int contador = 0;
        while (numero != 0) {
            numero /= 10;
            contador++;
        }
        return contador == 9;
    }
    
    }
    