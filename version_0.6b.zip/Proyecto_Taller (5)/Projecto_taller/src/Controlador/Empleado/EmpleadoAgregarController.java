package Controlador.Empleado;

import Controlador.SceneManager;
import Modelo.Cliente1;
import Modelo.Empleado;
import Modelo.Sucursal;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javax.swing.JOptionPane;
/**
 * FXML Controller class
 *
 * @author raito
 */
public class EmpleadoAgregarController implements Initializable {
    public String nom="",cargo="",dire="",depar="",sucur="",cedu="";
    public int tel;
    
    @FXML
    AnchorPane rootPane;
    
    public  Modelo.Sucursal suc= new Sucursal();
    
    @FXML
    private TextField EmpleadoNombre;

    @FXML
    private TextField EmpleadoCargo;

    @FXML
    private TextField EmpleadoTel;

    @FXML
    private TextField EmpleadoDir;

    @FXML
    private TextField EmpleadoDepar;

    @FXML
    private TextField EmpleadoSucursal;
    
     @FXML
    private TextField EmpCedu;

    @FXML
    private ComboBox<String> tipoDOC;
       
    String TipDocSel="";
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        rootPane.getStylesheets().add(getClass().getResource("/Estilos/Estilos.css").toExternalForm());
        tipoDOC.getItems().addAll("Cedula","Pasaporte","DNI","Cedula Extranjera","Licencia de Conducir");
    
     // Listener para actualizar el valor seleccionado en tiempo real
        tipoDOC.valueProperty().addListener((observable, oldValue, newValue) -> { 
            TipDocSel=newValue;
            System.out.println(TipDocSel);
     });
    
    
    }    
    
      @FXML
    void agregar(ActionEvent event) throws SQLException {
         Modelo.Empleado emp = new Empleado();
        String idsuc="";
        int id;
        nom=EmpleadoNombre.getText();
        if(nom.isEmpty()){
            // Crear y agregar un JLabel al panel
            JOptionPane.showMessageDialog(null, "nombre invalido");
            return;
        }
          System.out.println("nombre bien");
        cargo=EmpleadoCargo.getText();
        if(cargo.isEmpty()){
            // Crear y agregar un JLabel al panel
            JOptionPane.showMessageDialog(null, "cargo invalido o vacio");
            return;
        }
        System.out.println("cargo bien");
        dire=EmpleadoDir.getText();
        if(dire.isEmpty()){
           // Crear y agregar un JLabel al panel
           JOptionPane.showMessageDialog(null, "dirección invalida");
           return;
        }
          System.out.println("direccion bien");
        depar=EmpleadoDepar.getText();
        if(depar.isEmpty()){
             // Crear y agregar un JLabel al panel
           JOptionPane.showMessageDialog(null, "departamento invalida o vacio");
           return;
        }
          System.out.println("departamento bien");
        sucur=EmpleadoSucursal.getText();
        if(sucur.isEmpty()){
             // Crear y agregar un JLabel al panel
           JOptionPane.showMessageDialog(null, "sucursal invalida o vacia");
           return;
        }
          System.out.println("sucursal bien");
        cedu=EmpCedu.getText();
        if(cedu.isEmpty()){
            // Crear y agregar un JLabel al panel
           JOptionPane.showMessageDialog(null, "cedula invalida");
           return;
        }
          System.out.println("cedula bien");
        String te=EmpleadoTel.getText();
        if(te.length()<9){
             // Crear y agregar un JLabel al panel
           JOptionPane.showMessageDialog(null, "teléfono invalido");
           return;
        }else{
            tel=Integer.parseInt(te);
        }
          System.out.println("telefono bien");
          System.out.println("hasta aca todo bien");
         idsuc=Modelo.Sucursal.BuscarIDSucu(sucur);
          System.out.println("id sucursal: "+idsuc);
         id=Integer.parseInt(idsuc);
          emp.AgregarEmpleado(nom,cargo,tel,dire,depar,id,cedu,TipDocSel);
    }
   
    public void IrMenuEmpleado(){
        SceneManager.getInstance().goBackMenuEmpleado();
    }
}
