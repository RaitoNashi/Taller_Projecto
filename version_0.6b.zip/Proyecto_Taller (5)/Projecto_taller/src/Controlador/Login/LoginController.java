/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controlador.Login;

import Controlador.SceneManager;
import Modelo.Login.LoginUserAndPass;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javax.swing.JOptionPane;



public class LoginController implements Initializable {

private LoginUserAndPass LUAP = new LoginUserAndPass();    
    
@FXML
public TextField Usuario; 

@FXML
public PasswordField Contrasena;

@FXML
public Button Ingresar;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }   
    
    @FXML
    private void eventKey(KeyEvent event) {
        if (event.getEventType() == KeyEvent.KEY_TYPED) {
            Object evt = event.getSource();
            
            if (evt.equals(Usuario) || evt.equals(Contrasena)) {
                
                if (event.getCharacter().equals(" ") || event.getCharacter().equals("_") || event.getCharacter().equals("-")) {
                
                    event.consume(); // Evita que se inserte el espacio

                    TextField campo = (TextField) evt; // Puede ser Usuario o Contrasena 
                    // Guarda la posición actual del cursor
                     int posicionCursor = campo.getCaretPosition();
                    // Elimina los espacios en blanco en el texto
                    campo.setText(campo.getText().replace(" ", ""));
                    campo.setText(campo.getText().replace("-", ""));
                    campo.setText(campo.getText().replace("_", ""));

                    // Restaura la posición del cursor
                    campo.positionCaret(posicionCursor);
                }
            }
        }
    }


    @FXML
    private void HandleIngresar(ActionEvent event){
        Object evt = event.getSource();
        
        if(evt.equals(Ingresar)){
            if(!Usuario.getText().isEmpty() && !Contrasena.getText().isEmpty()){
                String  user = Usuario.getText();
                String  pass = Contrasena.getText();
                
                int state = LUAP.login(user, pass);
                
                if(state !=-1){
                    if(state == 1){
                        JOptionPane.showMessageDialog(null, "Datos correctos, puede ingresar al sistema");
                        SceneManager.getInstance().changeScene("/Vista/Menu_Principal.fxml");
                    }
                    else{
                        JOptionPane.showMessageDialog(null, "Datos incorrectos, NO puede ingresar al sistema");
                    }
                }
            }
            else{
                SceneManager.getInstance().MostrarPopUpEspaciosBlancosUsuarioContrasena();
            }
        }
    }
    
}
