package Modelo;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author 54255702
 */
public class CalcularStock {
    
        public static void CalcStock(String nomprod, int idpod) throws SQLException{
           Conexiónsql alta = new Conexiónsql();
         Connection conn = null;
        PreparedStatement psmt = null;
        conn = alta.getConnection();        
            ResultSet rs = null;
            ArrayList<String> ListaCategorias=new ArrayList<>();
        try{
            // Preparar la consulta
            String sql = "SELECT DISTINCT Categoria FROM producto;";
                psmt= conn.prepareStatement(sql);
                rs = psmt.executeQuery();
        // Iterar sobre el ResultSet y agregar cada categoría al ArrayList
        while (rs.next()) {
             String categoria = rs.getString("Categoria");
             ListaCategorias.add(categoria);
        }
           
            // Segunda consulta: Revisar el stock de cada categoría en ListaCategorias
        String sqlS = "SELECT Stock FROM producto WHERE Categoria = ?";
        psmt = conn.prepareStatement(sqlS);

        for (String categoria : ListaCategorias) {
            // Establecer el parámetro de la consulta con la categoría actual
            psmt.setString(1, categoria);           
            // Ejecutar la consulta de stock para la categoría actual
            rs = psmt.executeQuery();
            
            // Procesar el resultado del stock para la categoría
            while (rs.next()) {
                int stock = rs.getInt("Stock");
                if(stock<=20){
                    System.out.println("poco stock de produto "+nomprod+" de la categoria: "+categoria);
                }
                
            }
        }
        }
        catch (HeadlessException e) {
        JOptionPane.showMessageDialog(null, e + "No se encontrar el producto");
        }
         finally {
            // Cerrar ResultSet y PreparedStatement para liberar recursos
            if (rs != null) {
               try { rs.close(); } catch (SQLException e) { e.printStackTrace(); }
             }
           if (psmt != null) {
               try { psmt.close(); } catch (SQLException e) { e.printStackTrace(); }
             }
        }
        
    }
       
}