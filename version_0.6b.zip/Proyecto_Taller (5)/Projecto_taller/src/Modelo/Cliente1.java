package Modelo;

import Controlador.Factura.Ingresar_FacturaController;
import com.mysql.cj.xdevapi.Statement;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import Controlador.Cliente.Cliente_EliminarController;
import javafx.scene.control.TextField;
/**
 *
 * @author 54255702
 */

public class Cliente1 {
    //Metodo 1  
    public static boolean Altacliente(String nombre, String direccion, int telefono, String apellido, String cedula,String TipoDoc) throws SQLException{
        boolean resultado=true;
        Conexiónsql alta = new Conexiónsql();
        Connection conn = null;
        PreparedStatement psmt = null;
        ResultSet rs = null;
        conn = alta.getConnection();        
        int idCliente=0;
        String prsona="Cli";
        System.out.println("cedula y tipo documento"+cedula+" "+TipoDoc);
             try {
                 System.out.println("entramos al try");
                 String sqlMaxCliente="SELECT MAX(ID_Cliente) FROM cliente";
                    psmt = conn.prepareStatement(sqlMaxCliente);
                    rs = psmt.executeQuery();    
                    if (rs.next()) { 
                            idCliente = rs.getInt(1); // Obtener el valor con el índice de columna
                        }    
                    idCliente+=1;
                    System.out.println("trajimos el id y aumentamos"+idCliente);
                    
              //Hacemos la sentencia para hacer la sentencia sql
              String sql = "INSERT INTO cliente(Nombre,Dirección,Teléfono,apellido) VALUES (?,?,?,?)";
                    psmt = conn.prepareStatement(sql);
                        // Establecer los valores en el PreparedStatement y los ordenamos para cargarlos en la base de datos
                    psmt.setString(1,nombre);
                    psmt.setString(2,direccion);
                    psmt.setInt(3,telefono);                       
                    psmt.setString(4,apellido);
                    System.out.println("subimos los datos");
                        // Ejecutar la sentencia y obtener el número de filas afectadas
                    int filasAfectadas = psmt.executeUpdate();
                    System.out.println("hace el update");
                        //Si el numero de filas es mayor a 0 significa que se cargo los datos perfectamente
                    if(filasAfectadas>0){
                        System.out.println("entra al if");
                        System.out.println("filas afectadas"+filasAfectadas);
                            //Suben los datos de manera normal 
                            conn.commit();
                    }else{
                        System.out.println("error rolback");
                            //si no se afecto ninguna linea pasa al rolback donde y buelve todo a la normalidad. 
                            conn.rollback();
                            return false;
                        }
                        // Cerrar el PreparedStatement
                        psmt.close(); 
                        
                        System.out.println("vinioms a cargr documento");
              String sqldoc="INSERT INTO documento(num_documento,Tipo_Documento,Persona,id_persona) VALUES(?,?,?,?)";
                    psmt = conn.prepareStatement(sqldoc);
                        // Establecer los valores en el PreparedStatement y los ordenamos para cargarlos en la base de datos
                    psmt.setString(1,cedula);
                    psmt.setString(2,TipoDoc);
                    psmt.setString(3,prsona);
                    psmt.setInt(4,idCliente);
                // Ejecutar la sentencia y obtener el número de filas afectadas
                int fiAfecDoc = psmt.executeUpdate();
                  if (fiAfecDoc > 0) {
                          conn.commit();
                  } else {
                           conn.rollback();
                  }
                     psmt.close(); // Cerrar el segundo PreparedStatement
                     System.out.println("Cargamos el documento correctamente");
        } catch (HeadlessException | SQLException e) {
             System.out.println("catch de error");     
        JOptionPane.showMessageDialog(null, e + "No se Logro registrar al cliente");
        }
               if(conn!=null){
               conn.close();
           }
        return resultado;
        
    }
    
 //Metodo 2
    public static boolean AltaClienteJuridico(int TIN,String Nom_Emp,String Dir_Emp,String Correo,int Telef) throws SQLException{
        boolean resulta=true;                
        
         Conexiónsql alta = new Conexiónsql();
         Connection conn = null;
        PreparedStatement psmt = null;
        Scanner a = new Scanner(System.in);
        
        conn = alta.getConnection();        
         
             try {
                 //Hacemos la sentencia para hacer la sentencia sql
              String sql = "INSERT INTO cliente_juridico(Tin,Nom_emp,Dir_emp,Correo,Telefono) VALUES (?,?,?,?,?)";
                        psmt = conn.prepareStatement(sql);
                        // Establecer los valores en el PreparedStatement y los ordenamos para cargarlos en la base de datos
                        psmt.setInt(1,TIN);
                        psmt.setString(2,Nom_Emp);
                        psmt.setString(3,Dir_Emp);                       
                        psmt.setString(4,Correo);
                         psmt.setInt(5,Telef);
                       // psmt.executeUpdate();    
                        // Ejecutar la sentencia y obtener el número de filas afectadas
                        int filasAfectadas = psmt.executeUpdate();
                        //Si el numero de filas es mayor a 0 significa que se cargo los datos perfectamente
                        if(filasAfectadas>0){
                            //Suben los datos de manera normal 
                            conn.commit();
                        }else{
                            //si no se afecto ninguna linea pasa al rolback donde y buelve todo a la normalidad. 
                            conn.rollback();                           
                        }
                        // Cerrar el PreparedStatement
                        psmt.close();       
        } catch (HeadlessException | SQLException e) {
        JOptionPane.showMessageDialog(null, e + "No se Logro registrar al cliente");
        }
           if(conn!=null){
               conn.close();
           }
        return resulta;

    }
 
//Metodo 3
     public static boolean Mostrar_Clientes() throws SQLException{
             boolean resultado=true;
               Conexiónsql alta = new Conexiónsql();
         Connection conn = null;
        PreparedStatement psmt = null;
        
        conn = alta.getConnection();     
        try{ 
           // Preparar la consulta
            String sql = "SELECT Nombre, apellido FROM cliente WHERE ID_Cliente = 58";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            // Ejecutar la consulta
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                String nombre = rs.getString("nombre");
                String apellido = rs.getString("apellido");
                String mensaje = "Nombre: " + nombre + "\nApellido: " + apellido;
                JOptionPane.showMessageDialog(null, mensaje);
            } else {
                JOptionPane.showMessageDialog(null, "No se encontraron datos");
            }

            // Cerrar recursos
            rs.close();
            pstmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
            if(conn!=null){
            conn.close();
        }    
    return resultado;
}
    
 //Futuro "metodo 4" digamos
  public static boolean Borrar_Datos_Tabla(){
      boolean resultado=false;
      //DELETE FROM nombre_de_la_tabla;
             
      return resultado;
  }    
  
//Futuro "Metodo 5 de editar"
  
//Futuro "Metodo 7 de buscar"

//Futurp "Metodo 8 de subir empleado"
  
 

public String buscarProducto(String nom_prod) throws SQLException {
    String producto = null; // Variable para almacenar el nombre del producto encontrado
    Conexiónsql alta = new Conexiónsql();
    Connection conn = null;
    PreparedStatement psmt = null; 
    ResultSet rs = null;
        conn = alta.getConnection();        
    try {
      String sql = "SELECT * FROM cliente WHERE Nombre LIKE ?";
            // Preparar la sentencia
            psmt= conn.prepareStatement(sql);
            // Establecer el parámetro del LIKE (agregar % para buscar coincidencias en cualquier parte)
            psmt.setString(1, "%" + nom_prod + "%");
        // Ejecutar la consulta y obtener el resultado
        rs = psmt.executeQuery();

        // Verificar si se encontró el producto
        if (rs.next()) {
            producto = rs.getString("Nombre");
        } else {
            producto = "Producto no encontrado."; // Devolver mensaje si no se encuentra
        }
    } catch (SQLException e) {
        System.out.println("Error al obtener el producto: " + e.getMessage());
        throw e; // Re-lanzar la excepción para propagarla
    } 
    return producto;
}

public ArrayList<ArrayList<Object>> cargarProductos() throws SQLException {
        ArrayList<ArrayList<Object>> productos = new ArrayList<>();
        // Conexión a la base de datos (assuming Conexiónsql is defined elsewhere)
        Conexiónsql alta = new Conexiónsql();
        Connection conn = null;
        PreparedStatement psmt = null;
        ResultSet rs = null;

        try {
            // Get connection
            conn = alta.getConnection();

            if (conn == null) {
                System.err.println("Error: No se pudo establecer la conexión con la base de datos.");
                return productos; // Return an empty list on error
            }

            // Prepare SQL query
            String sql = "SELECT * FROM producto";
            psmt = conn.prepareStatement(sql);

            // Execute query and get results
            rs = psmt.executeQuery();

            if (rs == null) {
                System.err.println("Error: No se recibió ningún resultado de la consulta SQL.");
                return productos; // Return an empty list on error
            }

            // Process results
            while (rs.next()) {
                ArrayList<Object> fila = new ArrayList<>();
                fila.add(rs.getInt("ID_Producto"));  // ID
                fila.add(rs.getString("Nombre"));    // Nombre
               // System.out.println(rs.getString("Nombre"));
                fila.add(rs.getString("Descripcion")); // Descripción
                fila.add(rs.getFloat("Precio"));      // Precio
                System.out.println();
                fila.add(rs.getInt("Stock"));        // Stock
                 //   System.out.println("se hace todo bien papi");
                productos.add(fila);
            }
        } catch (SQLException e) {
            System.err.println("Error al conectar a la base de datos: " + e.getMessage());
            throw e; // Re-throw the exception for handling in the controller
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
                if (psmt != null) psmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }

        return productos;
    }

//traemos todo del cliente segun lo que haya
// Cambiar el método para aceptar un criterio de búsqueda como argumento
public ArrayList<ArrayList<Object>> TraerCliente(String criterio) throws SQLException {
    ArrayList<ArrayList<Object>> clien = new ArrayList<>();
      // Conexión a la base de datos (assuming Conexiónsql is defined elsewhere)
        Conexiónsql alta = new Conexiónsql();
        Connection conn = null;
        PreparedStatement psmt = null;
        ResultSet rs = null;
        
    try {
        // Obtener la conexión
        conn = alta.getConnection();
        
        if (conn == null) {
            System.err.println("Error: No se pudo establecer la conexión con la base de datos.");
            return clien;
        }

        // Preparar la consulta SQL
        String sql = "SELECT * FROM cliente WHERE Nombre LIKE ?";
        psmt = conn.prepareStatement(sql);
        psmt.setString(1, "%" + criterio + "%");  // Usar el criterio con un wildcard para LIKE
 
        // Ejecutar la consulta y obtener el resultado
        rs = psmt.executeQuery();

        // Procesar el resultado de la consulta
        while (rs.next()) {
            ArrayList<Object> fila = new ArrayList<>();
           // fila.add(rs.getInt("ID_Cliente"));
            fila.add(rs.getString("cedula"));  
            fila.add(rs.getString("Nombre"));   
            fila.add(rs.getString("apellido"));    
            fila.add(rs.getString("Dirección")); 
            fila.add(rs.getInt("Teléfono"));     
                 
            
            clien.add(fila);
        }
        
    } catch (SQLException e) {
        System.err.println("Error al conectar a la base de datos: " + e.getMessage());
    } finally {
        // Cerrar recursos
        try {
            if (rs != null) rs.close();
            if (psmt != null) psmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            System.err.println("Error al cerrar recursos: " + e.getMessage());
        }
    }
    return clien;    
}


//traemos todo del cliente Juridicos segun lo que haya
// Cambiar el método para aceptar un criterio de búsqueda como argumento
public ArrayList<ArrayList<Object>> TraerClienteJuridico (String criterio) throws SQLException {
    ArrayList<ArrayList<Object>> clien = new ArrayList<>();
      // Conexión a la base de datos (assuming Conexiónsql is defined elsewhere)
        Conexiónsql alta = new Conexiónsql();
        Connection conn = null;
        PreparedStatement psmt = null;
        ResultSet rs = null;
        
    try {
        // Obtener la conexión
        conn = alta.getConnection();
        
        if (conn == null) {
            System.err.println("Error: No se pudo establecer la conexión con la base de datos.");
            return clien;
        }

        // Preparar la consulta SQL
        String sql = "SELECT * FROM cliente_juridico WHERE Nom_emp LIKE ?";
        psmt = conn.prepareStatement(sql);
        psmt.setString(1, "%" + criterio + "%");  // Usar el criterio con un wildcard para LIKE
 
        // Ejecutar la consulta y obtener el resultado
        rs = psmt.executeQuery();

        // Procesar el resultado de la consulta
        while (rs.next()) {
            ArrayList<Object> fila = new ArrayList<>();
            fila.add(rs.getInt("Tin"));
            fila.add(rs.getString("Nom_emp"));  
            fila.add(rs.getString("Dir_emp"));   
            fila.add(rs.getString("Correo"));    
            fila.add(rs.getInt("Telefono"));     
                 
            
            clien.add(fila);
        }
        
    } catch (SQLException e) {
        System.err.println("Error al conectar a la base de datos: " + e.getMessage());
    } finally {
        // Cerrar recursos
        try {
            if (rs != null) rs.close();
            if (psmt != null) psmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            System.err.println("Error al cerrar recursos: " + e.getMessage());
        }
    }
    return clien;    
}



//Metodo 6  eliminar  
public String EliminarClienteDeTabla(String criAElim) throws SQLException {
    String exito = "exito";
    Conexiónsql alta = new Conexiónsql();
    Connection conn = null;
    PreparedStatement psmt = null;

    try {
        conn = alta.getConnection();
        if (conn == null) {
            System.err.println("Error: No se pudo establecer la conexión con la base de datos.");
            return "fracaso";
        }

        // Ejecutar la consulta DELETE
        String deleteSql = "DELETE FROM cliente WHERE cedula = ?";
        psmt = conn.prepareStatement(deleteSql);
        psmt.setString(1, criAElim);
        
        int rowsAffected = psmt.executeUpdate();

        if (rowsAffected > 0) {
            System.out.println("Cliente eliminado con éxito.");
             conn.commit();
            exito = "EXITO";
           
        } else {
            System.out.println("No se encontró ningún cliente con esa cédula.");
            conn.rollback(); 
            exito = "fracaso";
        }
    } catch (SQLException e) {
        exito = "fracaso";
        System.err.println("Error al eliminar el cliente: " + e.getMessage());
    } finally {
        // Cerrar recursos
        try {
            if (psmt != null) psmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            System.err.println("Error al cerrar recursos: " + e.getMessage());
        }
    }
    return exito;
}

//Metodo 7  eliminar  
public String EliminarClienteDeTablaju(int criAElim) throws SQLException {
    String exito = "exito";
    Conexiónsql alta = new Conexiónsql();
    Connection conn = null;
    PreparedStatement psmt = null;

    try {
        conn = alta.getConnection();
        if (conn == null) {
            System.err.println("Error: No se pudo establecer la conexión con la base de datos.");
            return "fracaso";
        }

        // Ejecutar la consulta DELETE
        String deleteSql = "DELETE FROM cliente_juridico WHERE Tin = ?";
        psmt = conn.prepareStatement(deleteSql);
        psmt.setInt(1, criAElim);
        
        int rowsAffected = psmt.executeUpdate();

        if (rowsAffected > 0) {
            System.out.println("Cliente eliminado con éxito.");
             conn.commit();
            exito = "EXITO";
           
        } else {
            System.out.println("No se encontró ningún cliente con esa cédula.");
            conn.rollback(); 
            exito = "fracaso";
        }
    } catch (SQLException e) {
        exito = "fracaso";
        System.err.println("Error al eliminar el cliente: " + e.getMessage());
    } finally {
        // Cerrar recursos
        try {
            if (psmt != null) psmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            System.err.println("Error al cerrar recursos: " + e.getMessage());
        }
    }
    return exito;
}

public boolean CambiarDatosCliente(String cedula,String nombre,String apel,String Direccion,int telefono){
    Conexiónsql alta = new Conexiónsql();
    Connection conn = null;
    PreparedStatement psmt = null;
    System.out.println("vinimos a la base de datos");
    
       try {
            conn = alta.getConnection();
            
           if(nombre!= null && !nombre.isEmpty()){
            // SQL para actualizar el nombre de un empleado según la cédula
            String sql = "UPDATE cliente SET Nombre = ? WHERE cedula = ?";
            // Crear PreparedStatement
            psmt = conn.prepareStatement(sql);
            // Establecer los parámetros del PreparedStatement
            psmt.setString(1, nombre);  // Establecer el nuevo nombre
            psmt.setString(2, cedula);       // Establecer la cédula para buscar al empleado  
            // Ejecutar la actualización
            int filasAfectadas = psmt.executeUpdate();    
            if (filasAfectadas > 0) {
                 conn.commit();
                System.out.println("Nombre del empleado actualizado con éxito.");
            } else {
                System.out.println("No se encontró ningún empleado con esa cédula.");
            }
           }
           
           if(apel!= null && !apel.isEmpty()){
            // SQL para actualizar el nombre de un empleado según la cédula
            String sql = "UPDATE cliente SET apellido = ? WHERE cedula = ?";
            // Crear PreparedStatement
            psmt = conn.prepareStatement(sql);
            // Establecer los parámetros del PreparedStatement
            psmt.setString(1, apel);  // Establecer el nuevo nombre
            psmt.setString(2, cedula);       // Establecer la cédula para buscar al empleado  
            // Ejecutar la actualización
            int filasAfectadas = psmt.executeUpdate();    
            if (filasAfectadas > 0) {
                 conn.commit();
                System.out.println("Apellido del empleado actualizado con éxito.");
            } else {
                System.out.println("No se encontró ningún empleado con esa cédula.");
            }
           }
           
            if(Direccion!= null && !Direccion.isEmpty()){
            // SQL para actualizar el nombre de un empleado según la cédula
            String sql = "UPDATE cliente SET Dirección = ? WHERE cedula = ?";
            // Crear PreparedStatement
            psmt = conn.prepareStatement(sql);
            // Establecer los parámetros del PreparedStatement
            psmt.setString(1, Direccion);  // Establecer el nuevo nombre
            psmt.setString(2, cedula);       // Establecer la cédula para buscar al empleado  
            // Ejecutar la actualización
            int filasAfectadas = psmt.executeUpdate();    
            if (filasAfectadas > 0) {
                 conn.commit();
                System.out.println("Dirección del empleado actualizado con éxito.");
            } else {
                System.out.println("No se encontró ningún empleado con esa cédula.");
            }
           }
           
             if(telefono>0){
            // SQL para actualizar el nombre de un empleado según la cédula
            String sql = "UPDATE cliente SET Teléfono = ? WHERE cedula = ?";
            // Crear PreparedStatement
            psmt = conn.prepareStatement(sql);
            // Establecer los parámetros del PreparedStatement
            psmt.setInt(1, telefono);  // Establecer el nuevo nombre
            psmt.setString(2, cedula);       // Establecer la cédula para buscar al empleado  
            // Ejecutar la actualización
            int filasAfectadas = psmt.executeUpdate();    
            if (filasAfectadas > 0) {
                 conn.commit();
                System.out.println("Teléfono del empleado actualizado con éxito.");
            } else {
                System.out.println("No se encontró ningún empleado con esa cédula.");
            }
           }
             
        }catch (SQLException e) {
            // Manejo de excepciones
            e.printStackTrace();
        } finally {
            // Cerrar recursos
            try {
                if (psmt != null) psmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
    
        return false;
}
}




}
