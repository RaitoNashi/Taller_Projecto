/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author 54255702
 */
public class Empleado {
    //Metodo 1  
    public void AgregarEmpleado(String Nombre,String Cargo,int Telefono,String Direccion,String Departamento,int ID_Sucursal,String Cedula,String TipoDoc) throws SQLException{     
        Conexiónsql alta = new Conexiónsql();
         Connection conn = null;
        PreparedStatement psmt = null;
        ResultSet rs = null;
        int idEmp=0;
        String prsona="Emp";
        conn = alta.getConnection();        
         
             try {
                  System.out.println("entramos al try");
                 String sqlMaxEmp="SELECT MAX(ID_Empleado) FROM empleado";
                    psmt = conn.prepareStatement(sqlMaxEmp);
                    rs = psmt.executeQuery();    
                    if (rs.next()) { 
                            idEmp = rs.getInt(1); // Obtener el valor con el índice de columna
                        }    
                    idEmp+=1;
                //Hacemos la sentencia para hacer la sentencia sql
                String sql = "INSERT INTO empleado(Nombre,Cargo,Telefono,Direccion,Departamento,ID_Sucursal) VALUES (?,?,?,?,?,?)";
                        psmt = conn.prepareStatement(sql);
                        // Establecer los valores en el PreparedStatement y los ordenamos para cargarlos en la base de datos
                        psmt.setString(1,Nombre);
                        psmt.setString(2,Cargo);
                        psmt.setInt(3,Telefono);                       
                        psmt.setString(4,Direccion);
                        psmt.setString(5,Departamento);
                        psmt.setInt(6,ID_Sucursal);
                        //psmt.executeUpdate();    
                        // Ejecutar la sentencia y obtener el número de filas afectadas
                        int filasAfectadas = psmt.executeUpdate();
                        //Si el numero de filas es mayor a 0 significa que se cargo los datos perfectamente
                        if(filasAfectadas>0){
                             //hacemos un jpanel mostrando que el cliente se cargo con exito. 
                             JOptionPane.showMessageDialog(null, "Empleado registrado con exito");
                            //Suben los datos de manera normal 
                            conn.commit();
                        }else{
                            //si no se afecto ninguna linea pasa al rolback donde y buelve todo a la normalidad. 
                            conn.rollback();
                        }
                        // Cerrar el PreparedStatement
                        psmt.close();    
                String sqldoc="INSERT INTO documento(num_documento,Tipo_Documento,Persona,id_persona) VALUES(?,?,?,?)";
                    psmt = conn.prepareStatement(sqldoc);
                        // Establecer los valores en el PreparedStatement y los ordenamos para cargarlos en la base de datos
                    psmt.setString(1,Cedula);
                    psmt.setString(2,TipoDoc);
                    psmt.setString(3,prsona);
                    psmt.setInt(4,idEmp);
                // Ejecutar la sentencia y obtener el número de filas afectadas
                int fiAfecDoc = psmt.executeUpdate();
                  if (fiAfecDoc > 0) {
                          conn.commit();
                  } else {
                           conn.rollback();
                  }
                psmt.close(); // Cerrar el segundo
        } catch (HeadlessException | SQLException e) {
        JOptionPane.showMessageDialog(null, e + "No se Logro registrar al cliente");
        }
               if(conn!=null){
               conn.close();
        }
        
    }
    
    
    
    
    
    
    
    
}
