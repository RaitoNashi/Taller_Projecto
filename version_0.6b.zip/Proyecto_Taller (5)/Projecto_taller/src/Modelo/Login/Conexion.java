package Modelo.Login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Conexion {
    private static Conexion instance; // Instancia única de la clase
    private Connection Conectador;

    private final String url;
    private final String user = "root";
    private final String password = "";
    private final String driver = "com.mysql.cj.jdbc.Driver";

    // Constructor privado para el patrón singleton
    private Conexion(String bd) {
        this.url = "jdbc:mysql://localhost:3306/" + bd;
        conectar();
    }

    // Método para obtener la instancia única de Conexion
    public static Conexion getInstance(String bd) {
        if (instance == null) {
            instance = new Conexion(bd);
        }
        return instance;
    }

    // Método para conectar a la base de datos
    private void conectar() {
        try {
            Class.forName(driver);
            Conectador = DriverManager.getConnection(url, user, password);
           // System.out.println("Conectado a la base de datos.");
        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println("No se pudo conectar a la base de datos.");
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // Método público para obtener la conexión
    public Connection getConnection() {
        return Conectador;
    }

    // Método para desconectar la base de datos
    public void desconectar() {
        try {
            if (Conectador != null && !Conectador.isClosed()) {
                Conectador.close();
              //  System.out.println("Desconectado de la base de datos.");
            }
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
