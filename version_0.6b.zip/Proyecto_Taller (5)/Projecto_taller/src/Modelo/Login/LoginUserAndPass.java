/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo.Login;

import java.awt.HeadlessException;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
     

/**
 *
 * @author raito
 */
public class LoginUserAndPass {
    public int login(String user, String password){
        Connection conexion = null;
        PreparedStatement PST;
        ResultSet RS;
        int state = -1;
        
        try {
            conexion = Conexion.getInstance("ferreteria").getConnection();
            
            if(conexion != null){
                String sql ="SELECT * FROM usuarios WHERE BINARY usuario=? AND contraseña=?";
                
                PST = conexion.prepareStatement(sql);
                PST.setString(1, user);
                PST.setString(2,password);
                
                RS = PST.executeQuery();
                
                if(RS.next()){
                    state = 1;
                }else{
                    state = 0;
                }
                
            }else{
                JOptionPane.showMessageDialog(null, "Hubo un error al conectarse a la base de datos");
            }
            
        }catch (HeadlessException | SQLException ex) {
            JOptionPane.showMessageDialog(null, "error" + ex.getMessage());
        } 
        finally {
             if(conexion != null){
                  Conexion.getInstance("ferreteria").desconectar();
              }
        }
        

        return state ;
    }
}
