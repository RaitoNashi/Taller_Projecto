package Controlador.Factura;

import Controlador.SceneManager;
import Modelo.Cliente1;
import Modelo.Conexiónsql;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import java.util.ArrayList;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import java.time.LocalDate;
import javafx.scene.control.DatePicker;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javafx.scene.control.cell.PropertyValueFactory;
import java.lang.Math;
import java.lang.String;
import Controlador.Factura.cargarTabla;
import Modelo.BuscarDeProducto;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableCell;
import javafx.stage.Stage;
//nuevo
/**
 * FXML Controller class
 *
 * @author raito
 */

public class Ingresar_FacturaController implements Initializable {
    Modelo.Cliente1 cli2=new Modelo.Cliente1();
   public int auxsubtotal=0;
   public int cantidadprod;
   public double unitpr;
   public double subtoto;
   public int auxiliar;
   public String au;
   String ideaProd="";
   public  boolean cargo=true;
   public String nombreProducto="";
   public String prod="";
     
    // Cambiar la declaración de buscProdCon
    public BuscarDeProducto buscProdCon;
    
   // boolean cargo= Modelo.Cliente1.CargarDetalleVentna(cantidadprod, cantidadprod, unitpr);
    public ComboBox<String> conxxx;  // ComboBox de JavaFX
    
    @FXML
    public ComboBox<String> ConClientes; //ComboBox de Clientes

    @FXML
    public ComboBox<String> conEmpleado; //ComboBox Empleado
    
    @FXML
    public TableView<cargarTabla> tableView; // Renombrado para mayor claridad
    @FXML
    public TableColumn<cargarTabla, String> Produco;
    @FXML
    public TableColumn<cargarTabla, Integer> Cantid;
    @FXML
    public TableColumn<cargarTabla, Double> UbitPrecio; // Cambiado a Double
    @FXML
    public TableColumn<cargarTabla, Double> subTotal; // Cambiado a Double
    public TextField IDVenta;
    public TextField IDProducto;
    @FXML
    public TextField CantProducto;
    public TextField Cedula;
    @FXML
    public DatePicker fecha;
    @FXML
    public Button agregarr;
    @FXML
    public TextField TOTAL;
    @FXML
    public TextField buscProd;
    
    public ArrayList<cargarTabla>ListaDatos=new ArrayList<>();
    
     public Ingresar_FacturaController(){
         
     }
     // Constructor con parámetro para inyección
    public Ingresar_FacturaController(BuscarDeProducto buscarDeProducto) {
        this.buscProdCon = buscarDeProducto; // Inyección de dependencia
    }
    
    // Constructor alternativo con parámetro de nombreProducto
    public Ingresar_FacturaController(String nombreProducto) {
        this.nombreProducto = nombreProducto; // Asigna el valor de nombreProducto
    }
   
      // ArrayList listaDatos = new ArrayList<>(); 
    @Override
    public void initialize(URL url, ResourceBundle rb){
         // Inicializar el TextField vacío
      buscProd = new TextField();  // Esto debe ser la forma correcta si no estás usando FXML
     // TODO     
        Conexiónsql alta = new Conexiónsql();
        Connection conn = null;
        //llenarComboBoxConDatos();
        llenarComboBoxCliente();
        llenarComboBoxEmpleado();
       
        // Inicializa las columnas
        Produco.setCellValueFactory(new PropertyValueFactory<>("producto"));
        Cantid.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
        UbitPrecio.setCellValueFactory(new PropertyValueFactory<>("unitprecio"));
        subTotal.setCellValueFactory(new PropertyValueFactory<>("SubTotal"));
       /*Configura el cellFactory para la columna UbitPrecio
    UbitPrecio.setCellFactory(column -> {
        return new TableCell<cargarTabla, Double>() { // Asegúrate de que 'cargarTabla' sea el tipo correcto
            @Override
            public void updateItem(Double item, boolean empty) {
                item=22.4;
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);  // Celda vacía
                } else {
                    setText(String.format("%.2f", item));  // Mostrar el precio formateado
                    setStyle("-fx-alignment: CENTER-RIGHT;");  // Alinear a la izquierda
                }
            }
        };
    });*/
      // Inicializa las variables
    cantidadprod = 0;
    unitpr = 0.0;
    
}  
    
    @FXML
    public void MostrarMenuPrincipal(){ 
        SceneManager.getInstance().goBack();
    }
    
    //Este PopUp está iniciliazado en el controlador SceneManager
    @FXML
    public void MostrarPopUp() throws SQLException{
     // Modelo.Cliente1 cli1 = new Modelo.Cliente1();
        cargo = cli2.CardarDetalleVentna(cantidadprod, cantidadprod, (float) unitpr);
        if(cargo!=true){
            System.out.println(cargo);
        }else{
            System.out.println("error");
        }
        SceneManager.getInstance().MostrarPopUp();
        limpiarCampos();
    }
   
    public void limpiarCampos(){
        IDVenta.clear();
        IDProducto.clear();
        CantProducto.clear();
        Cedula.clear();
        
    }
    
    //LLENAR LA TABLA
    public void cargarDatos() throws SQLException {
    // Limpiar la lista antes de cargar nuevos datos
    String prodddd = prod;
    ListaDatos.clear();
    // Verificar si hay un producto seleccionado en el ComboBox
    
       System.out.println("EMAAAAAA"+prodddd);
    if (prodddd.isEmpty()) {
        System.out.println("No se ha seleccionado ningún producto.");
        return; // Salir del método si no hay selección
    }
    // Obtener la cantidad del TextField y convertirla a int
    try {
        cantidadprod = Integer.parseInt(CantProducto.getText());
    } catch (NumberFormatException e) {
        System.out.println("La cantidad ingresada no es un número válido.");
        return; // Salir del método si la conversión falla
    }
     // Obtener el precio del producto
    try {
    unitpr = Modelo.Cliente1.TraerPrecio(prodddd);
    } catch (SQLException e) {
    System.out.println("Error al obtener el precio: " + e.getMessage());
    return; // Salir del método si hay un error
}
    // Calcular subtoto y cargar en la lista
    subtoto=unitpr*cantidadprod;
    // Simular la carga de datos locales
    ListaDatos.add(new cargarTabla(prodddd, cantidadprod,unitpr, subtoto));

   // Actualizar la tabla
    tableView.getItems().addAll(ListaDatos); // Agregar todos los elementos de la lista
    int u=(int) Math.round(subtoto);
    auxsubtotal += u;//auxsubtotal=u+auxsubtotal;
    TOTAL.setText(String.valueOf(auxsubtotal));
    
    au = Modelo.Cliente1.TraerIDProd(prodddd);
if (au != null) {
    auxiliar = Integer.parseInt(au);
} else {
        System.out.println("No se pudo obtener el ID del producto.");
    }
}
    
    /*hay problemas con la variable nombreProducto, si vien guarda un mensaje se e atribulle null despues 
    en cualquier parte del código    buscProd*/
     public void actuTextFieldConProdSelec(String mensaje) {
       prod = mensaje; // Asigna el valor de mensaje a nombreProducto
        System.out.println("IMPORTANTEEEEEEEEEEEE: "+prod);
       System.out.println(prod);
       
       
        if (buscProd != null) {
            buscProd.setText(prod);
            System.out.println("TextField actualizado con: "+prod);
        } else {
            System.out.println("Error: buscProd es null");
        }
    }
        
      
    //COMBOX
     public void llenarComboBoxCliente() {
        // Llamar al método que obtiene los datos
        ArrayList<String> listaDeClientes = cli2.cargarDatosEnComboBoxCliente();
        // Limpiar el ComboBox antes de agregar nuevos datos
        ConClientes.getItems().clear();
         // Llenar el ComboBox con los datos obtenidos
         ConClientes.getItems().addAll(listaDeClientes);
    }
      
      public void llenarComboBoxEmpleado() {      
        // Llamar al método que obtiene los datos
        ArrayList<String> listaDeEmpleado = cli2.llenarComboBoxEmpleado();
        // Limpiar el ComboBox antes de agregar nuevos datos
        conEmpleado.getItems().clear();
        // Llenar el ComboBox con los datos obtenidos
        conEmpleado.getItems().addAll(listaDeEmpleado);
    }
      
      //boton de agregar a la tablathrows SQLException 
    @FXML
    public void agregar(ActionEvent event) throws SQLException {
    //prod = nombreProducto; // Asegúrate de que prod esté asignado en cada llamada
    double fprecio;
    System.out.println("IMPRECIONABLE: "+prod);
    
    if (prod != null && !prod.isEmpty()) {
        fprecio = Modelo.Cliente1.TraerPrecio(prod);
        System.out.println("Precio obtenido: " + fprecio);
        cargarDatos(); // Llama a cargarDatos aquí si prod es válido
    } else {
        System.out.println("No se ha seleccionado ningún producto.");
    }
      cargarDatos();
}

    @FXML
    public void buscar(ActionEvent event) throws SQLException, IOException {
      try {
            // Cargar el nuevo FXML
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Vista/Facturación/Vista_Buscador_Producto.fxml"));
            Parent root = loader.load();

            // Crear un nuevo escenario
            Stage nuevoStage = new Stage();
            nuevoStage.setScene(new Scene(root));
            nuevoStage.setTitle("Buscar Producto");
            nuevoStage.show(); // Mostrar el nuevo escenario

        } catch (IOException e) {
            e.printStackTrace();
        }   
        // SceneManager.getInstance().changeScene("/Vista/Facturación/Vista_Buscador_Producto.fxml");
    }     

   
}


