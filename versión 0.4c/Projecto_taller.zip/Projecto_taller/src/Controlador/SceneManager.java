package Controlador;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Stack;
import javafx.scene.control.Alert;

public class SceneManager {
    private static SceneManager instance;
    private Stage primaryStage;
    private Stack<String> sceneHistory = new Stack<>();

    private SceneManager() {}

    public static SceneManager getInstance() {
        if (instance == null) {
            instance = new SceneManager();
        }
        return instance;
    }

    public void setPrimaryStage(Stage stage) {
        this.primaryStage = stage;
    }

    public void changeScene(String fxmlFilePath) {
    if (fxmlFilePath == null || fxmlFilePath.isEmpty()) {
        throw new IllegalArgumentException("FXML file path cannot be null or empty");
    }

    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFilePath));
        Parent root = loader.load();
        primaryStage.setScene(new Scene(root));
        primaryStage.show();
    } catch (IOException e) {
        e.printStackTrace();
    }
}   
    private String getCurrentSceneFilePath() {
        Scene currentScene = primaryStage.getScene();
        if (currentScene != null && currentScene.getUserData() != null) {
            return (String) currentScene.getUserData();
        }
        return null;
    }
    /**
     * El llamado de esta función permite al usuario retornar a la vista del Menu Principal
     * Se debe colocar dentro de una función en el controlador requerido y llamarlo de la misma forma
     * que la variable en el archivo FXML con su respectivo onAction = "#Variable"
     */
    public void goBack() {
        SceneManager.getInstance().changeScene("/Vista/Menu_Principal.fxml");
    }
    
    /**
     * El llamado de esta función permite al usuario retornar a la vista del Menu Cliente
     * Se debe colocar dentro de una función en el controlador requerido y llamarlo de la misma forma
     * que la variable en el archivo FXML con su respectivo onAction = "#Variable"
     */
    public void goBackMenuCliente(){
        SceneManager.getInstance().changeScene("/Vista/Cliente/Cliente_Menu.fxml");
    }
    
    /**
     * El llamado de esta función permite al usuario retornar a la vista del Menu Empleado
     * Se debe colocar dentro de una función en el controlador requerido y llamarlo de la misma forma
     * que la variable en el archivo FXML con su respectivo onAction = "#Variable"
     */
    public void goBackMenuEmpleado(){
        SceneManager.getInstance().changeScene("/Vista/Empleado/EmpleadoMenu.fxml");
    }
    
    /**
     * El llamado de esta función permite al usuario mostrar un pop up
     * Se debe colocar dentro de una función en el controlador requerido y llamarlo de la misma forma
     * que la variable en el archivo FXML con su respectivo onAction = "#Variable"
     */
    public void MostrarPopUp(){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Envío Exitoso");
        alert.setHeaderText(null);
        alert.setContentText("El formulario ha sido enviado correctamente.");
        alert.showAndWait();
    }
}
