/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo.Historial;

import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.DriverManager;
import java.sql.SQLException;

//Clase donde se inicializan las variables para la conexión
public class Conexion {
    String bd="";
    String url="jdbc:mysql://localhost:3306/";
    String user="root";
    String password="";
    String driver="com.mysql.cj.jdbc.Driver";
    Connection Conectador;

//Constructor de la clase Conexion
    public Conexion(String bd) {
        this.bd=bd;
        this.url = "jdbc:mysql://localhost:3306/" + bd;
    }
    
//Método para conectarse a la base de datos
    public Connection Conectar(){
        
        try {
            Class.forName(driver);
            Conectador = DriverManager.getConnection(url, user, password);
            System.out.println("Se conecto Nashe");
        } catch (ClassNotFoundException | SQLException ex) {
             System.out.println("No se conecto a la base");
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Conectador;
    }
    
    public void desonectar(){
        try {
            Conectador.close();
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
